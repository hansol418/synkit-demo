"""문서에 찍힌 표기를 정규 값으로 되돌린다. variations(생성)의 역함수. (devplan 4.7)

규칙은 채점 입력 명세(D2)와 같다: 대소문자와 앞뒤 공백을 무시하고, 단위 별칭과 환산 단위를 해석하며,
다중 선택은 별칭을 정규 값으로 바꿔 스키마 순서의 집합으로 본다. 6단계 채점기가 같은 함수를 쓴다.

해석할 수 없는 표기(오타 등)는 `UnknownNotation`을 낸다. 값을 지어내지 않는다.
"""

from __future__ import annotations

from typing import Any

from synkit.schema.models import Requirement


class UnknownNotation(ValueError):
    """스키마의 표기 목록(단위, 별칭, 허용 값)으로 해석할 수 없는 표기."""


def _key(text: Any) -> str:
    return " ".join(str(text).casefold().split())


def _unit_table(spec: Requirement) -> dict[str, str | None]:
    """표기 → 환산 원본 단위. None이면 정규 단위."""
    aliases = spec.unit_aliases or {}
    table: dict[str, str | None] = {_key(spec.unit): None}
    for spelling in aliases.get(spec.unit, []):
        table[_key(spelling)] = None
    for source in spec.conversions or {}:
        table[_key(source)] = source
        for spelling in aliases.get(source, []):
            table[_key(spelling)] = source
    return table


def _choice_table(spec: Requirement) -> dict[str, str]:
    table = {_key(value): value for value in spec.values or []}
    for value, spellings in (spec.aliases or {}).items():
        for spelling in spellings:
            table[_key(spelling)] = value
    return table


def _normalize_number(spec: Requirement, value: Any, unit: str | None):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"숫자 요구사항의 값이 숫자가 아닙니다: {value!r}")
    if unit is None:
        raise UnknownNotation("숫자에 단위가 없습니다.")
    table = _unit_table(spec)
    key = _key(unit)
    if key not in table:
        raise UnknownNotation(f"알 수 없는 단위입니다: {unit!r}")
    source = table[key]
    if source is None:
        return value
    conversion = spec.conversions[source]
    return value * conversion.factor + conversion.offset


def _normalize_choice(spec: Requirement, value: Any) -> str:
    if not isinstance(value, str):
        raise TypeError(f"선택 값이 문자열이 아닙니다: {value!r}")
    table = _choice_table(spec)
    key = _key(value)
    if key not in table:
        raise UnknownNotation(f"알 수 없는 값입니다: {value!r}")
    return table[key]


def normalize_shown(spec: Requirement, value: Any, unit: str | None = None) -> Any:
    """문서에 찍힌 값(value)과 단위(unit)를 정규 값으로. 해석할 수 없으면 UnknownNotation."""
    if spec.type == "number":
        return _normalize_number(spec, value, unit)
    if spec.type == "category":
        return _normalize_choice(spec, value)
    if spec.type == "multi_select":
        if not isinstance(value, (list, tuple)):
            raise TypeError(f"다중 선택 값이 목록이 아닙니다: {value!r}")
        found = {_normalize_choice(spec, element) for element in value}
        return [v for v in spec.values if v in found]  # 스키마 순서의 집합
    return value
