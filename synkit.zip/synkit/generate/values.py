"""요구사항 유형별 값 생성.

sample_value: 제약만 지키는 임의 값 (제품 사양 생성에 쓴다)
sample_for_intent: 제품 사양에 대해 원하는 적합성(comply / partial / non_comply)이 나오도록 값을 뽑는다.
의도를 만들 수 없으면 comply로 떨어진다. 어느 쪽이든 정답은 compliance.evaluate로 다시 계산한다.
"""

from __future__ import annotations

import random
from typing import Any

from synkit.generate.compliance import COMPLY, NON_COMPLY, PARTIAL, evaluate
from synkit.schema.models import Requirement

INTENTS = ("comply", "partial", "non_comply")
_TARGET = {"comply": COMPLY, "partial": PARTIAL, "non_comply": NON_COMPLY}
_MAX_TRIES = 300


# ---------------------------------------------------------------- 임의 값

def _is_integer_range(requirement: Requirement) -> bool:
    low, high = requirement.range
    return float(low).is_integer() and float(high).is_integer()


def _fit_number(requirement: Requirement, value: float) -> float | int:
    """범위 안으로 맞추고, 범위가 정수면 정수, 아니면 소수 둘째 자리로 둔다."""
    low, high = requirement.range
    if _is_integer_range(requirement):
        return int(min(max(round(value), int(low)), int(high)))
    return min(max(round(value, 2), low), high)


def _random_subset(rng: random.Random, pool: list[str]) -> list[str]:
    """pool의 비어 있지 않은 부분집합. pool의 순서를 유지한다."""
    chosen = set(rng.sample(pool, rng.randint(1, len(pool))))
    return [v for v in pool if v in chosen]


def sample_value(rng: random.Random, requirement: Requirement) -> Any:
    if requirement.type == "number":
        low, high = requirement.range
        if _is_integer_range(requirement):
            return rng.randint(int(low), int(high))
        return _fit_number(requirement, rng.uniform(low, high))
    if requirement.type == "category":
        return rng.choice(requirement.values)
    if requirement.type == "multi_select":
        return _random_subset(rng, requirement.values)
    return f"text_{rng.randint(1000, 9999)}"


# ---------------------------------------------------------------- 의도에 맞는 값

def _number_window(compare: str, intent: str, product: float, tol: float):
    """의도에 맞는 요구값이 있을 만한 구간. None이면 전체 범위에서 뽑는다."""
    if intent == "comply":
        return {"min": (None, product), "max": (product, None)}.get(compare)
    if intent == "partial":
        if compare == "min":
            return (product, product / (1 - tol) if tol < 1 else None)
        if compare == "max":
            return (product / (1 + tol), product)
        return (product / (1 + tol), product / (1 - tol) if tol < 1 else None)
    if compare == "min":  # non_comply
        return (product / (1 - tol) if tol < 1 else None, None)
    if compare == "max":
        return (None, product / (1 + tol))
    return None


def _number_for_intent(rng, requirement, product, intent, tol):
    compare = requirement.compare or "eq"
    if intent == "comply" and compare == "eq":
        return product

    low, high = requirement.range
    window = _number_window(compare, intent, product, tol)
    a, b = (low, high) if window is None else window
    a = low if a is None else max(low, a)
    b = high if b is None else min(high, b)

    if a <= b:
        target = _TARGET[intent]
        for _ in range(_MAX_TRIES):
            candidate = _fit_number(requirement, rng.uniform(a, b))
            if evaluate(requirement, candidate, product, tol) == target:
                return candidate

    # 의도를 만들 수 없다: 충족하는 값으로 떨어진다
    return _number_for_intent(rng, requirement, product, "comply", tol) if intent != "comply" else product


def _choice_for_intent(rng, requirement, product, intent):
    others = [v for v in requirement.values if v != product]
    if intent != "comply" and others:  # category는 Partial이 없어 Non-Comply로 만든다
        return rng.choice(others)
    return product


def _multi_for_intent(rng, requirement, product, intent):
    have = [v for v in requirement.values if v in set(product)]
    missing = [v for v in requirement.values if v not in set(product)]

    if intent == "partial" and have and missing:
        chosen = set(_random_subset(rng, have)) | set(_random_subset(rng, missing))
        return [v for v in requirement.values if v in chosen]
    if intent == "non_comply" and missing:
        return _random_subset(rng, missing)
    return _random_subset(rng, have or requirement.values)


def sample_for_intent(rng, requirement: Requirement, product: Any, intent: str, tolerance: float):
    if intent not in INTENTS:
        raise ValueError(f"알 수 없는 의도: {intent}")
    if requirement.type == "number":
        return _number_for_intent(rng, requirement, product, intent, tolerance)
    if requirement.type == "category":
        return _choice_for_intent(rng, requirement, product, intent)
    if requirement.type == "multi_select":
        return _multi_for_intent(rng, requirement, product, intent)
    return sample_value(rng, requirement)
