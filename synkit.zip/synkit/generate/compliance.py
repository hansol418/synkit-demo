"""적합성(Comply / Non-Comply / Partial) 판정 규칙. docs/decisions.md 15번.

정답은 항상 이 함수 하나에서 나온다. 생성 의도(values.py)가 아니라 여기서 다시 계산한 값을 기록하므로
생성과 채점의 판정 기준이 어긋나지 않는다.
"""

from __future__ import annotations

from typing import Any

from synkit.schema.models import Requirement

COMPLY = "Comply"
NON_COMPLY = "Non-Comply"
PARTIAL = "Partial"

_EPS = 1e-9  # 부동소수점 표현 오차 흡수용 (허용 오차와 무관)


def evaluate(requirement: Requirement, required: Any, product: Any, tolerance: float) -> str | None:
    """요구값(required)을 제품 사양(product)이 충족하는지 판정한다.

    - number: compare가 eq면 같아야 하고, min이면 제품 ≥ 요구값, max면 제품 ≤ 요구값.
      Partial은 요구값 대비 tolerance 이내로 어긋난 경우다.
    - category: 같으면 Comply, 다르면 Non-Comply (Partial 없음)
    - multi_select: 요구 ⊆ 제품이면 Comply, 일부만 겹치면 Partial, 겹치지 않으면 Non-Comply
    - text: 판정하지 않는다 (None)
    """
    kind = requirement.type
    if kind == "number":
        return _evaluate_number(requirement.compare or "eq", required, product, tolerance)
    if kind == "category":
        return COMPLY if required == product else NON_COMPLY
    if kind == "multi_select":
        wanted, have = set(required), set(product)
        if wanted <= have:
            return COMPLY
        return PARTIAL if wanted & have else NON_COMPLY
    return None


def _evaluate_number(compare: str, required: float, product: float, tolerance: float) -> str:
    scale = max(1.0, abs(required))
    slack = tolerance * abs(required) + _EPS * scale

    if compare == "min":  # 제품이 요구값 이상이어야 한다
        if product >= required - _EPS * scale:
            return COMPLY
        return PARTIAL if required - product <= slack else NON_COMPLY

    if compare == "max":  # 제품이 요구 한도 이하여야 한다
        if product <= required + _EPS * scale:
            return COMPLY
        return PARTIAL if product - required <= slack else NON_COMPLY

    diff = abs(product - required)  # eq
    if diff <= _EPS * scale:
        return COMPLY
    return PARTIAL if diff <= slack else NON_COMPLY
