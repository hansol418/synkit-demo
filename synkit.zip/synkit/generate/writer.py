"""생성 결과를 실행 폴더(runs/<run_id>/)에 기록한다. docs/decisions.md 18번.

- 데이터 파일에는 시각과 run_id를 넣지 않는다. 같은 시드와 스키마면 바이트 단위로 같다.
- 시각, run_id, 파일 해시는 run_meta.json에만 둔다.
- 기존 실행 폴더는 덮어쓰지 않는다.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from synkit import __version__
from synkit.constants import CONTRACT_VERSION, LIMITATION_NOTICE
from synkit.generate.models import Dataset
from synkit.generate.variations import summarize_variations
from synkit.schema.models import Schema

DATA_FILES = (
    "product_db.csv", "dataset.csv", "ground_truth.json", "document_plan.json", "schema.yaml",
)


@dataclass(frozen=True)
class RunResult:
    run_id: str
    path: Path


def _cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return "|".join(str(v) for v in value)
    return str(value)


def _csv_bytes(header: list[str], rows: list[list[str]]) -> bytes:
    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(rows)
    return buffer.getvalue().encode("utf-8-sig")  # 엑셀에서 한글이 깨지지 않도록 BOM


def _json_bytes(data: Any) -> bytes:
    return (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _product_db_bytes(dataset: Dataset, schema: Schema) -> bytes:
    ids = [r.id for r in schema.requirements]
    rows = [[m.model_id] + [_cell(m.specs[i]) for i in ids] for m in dataset.models]
    return _csv_bytes(["model_id"] + ids, rows)


def _dataset_bytes(dataset: Dataset) -> bytes:
    rows = []
    for doc in dataset.documents:
        status = {c.id: c.status for c in doc.compliance}
        for req in doc.requirements:
            rows.append([
                doc.doc_id, doc.template, doc.target_model, req.id,
                _cell(req.value), _cell(req.unit), status.get(req.id, ""),
            ])
    header = ["doc_id", "template", "target_model", "requirement_id", "value", "unit", "compliance"]
    return _csv_bytes(header, rows)


def _ground_truth_bytes(dataset: Dataset) -> bytes:
    documents = []
    for doc in dataset.documents:
        requirements = []
        for req in doc.requirements:
            item = {"id": req.id, "value": req.value}
            if req.unit is not None:
                item["unit"] = req.unit
            requirements.append(item)
        documents.append({
            "doc_id": doc.doc_id,
            "template": doc.template,
            "target_model": doc.target_model,
            "requirements": requirements,
            "compliance": [{"id": c.id, "status": c.status} for c in doc.compliance],
        })
    return _json_bytes({"schema_version": "1", "documents": documents})


def _document_plan_bytes(dataset: Dataset) -> bytes:
    """렌더러(M4)가 읽는 문서 계획. 정답과 분리해 '문서에 무엇이 어떻게 찍히는가'만 담는다."""
    documents = []
    for doc in dataset.documents:
        items = [
            {
                "id": item.id,
                "present": item.present,
                "shown_value": item.shown_value,
                "shown_unit": item.shown_unit,
                "converted_from": item.converted_from,
                "variations": list(item.variations),
            }
            for item in doc.display
        ]
        documents.append(
            {"doc_id": doc.doc_id, "template": doc.template, "language": doc.language, "items": items}
        )
    return _json_bytes({"schema_version": "1", "documents": documents})


def _create_run_dir(out_dir: Path, base: str) -> tuple[str, Path]:
    run_id, suffix = base, 1
    while True:
        path = out_dir / run_id
        try:
            path.mkdir()
            return run_id, path
        except FileExistsError:
            suffix += 1
            run_id = f"{base}-{suffix}"


def write_run(
    dataset: Dataset,
    schema: Schema,
    schema_text: str,
    out_dir: str | Path,
    *,
    now: datetime | None = None,
) -> RunResult:
    now = now or datetime.now()
    # 시각은 시간대(오프셋)를 포함해 기록한다. 시간대가 없으면 이 PC의 시간대를 붙인다. (시계 값은 그대로)
    aware_now = now if now.tzinfo is not None else now.astimezone()
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    run_id, run_path = _create_run_dir(out_dir, f"{now:%Y%m%d-%H%M%S}-s{dataset.seed}")

    contents = {
        "product_db.csv": _product_db_bytes(dataset, schema),
        "dataset.csv": _dataset_bytes(dataset),
        "ground_truth.json": _ground_truth_bytes(dataset),
        "document_plan.json": _document_plan_bytes(dataset),
        "schema.yaml": schema_text.encode("utf-8"),
    }
    for name, data in contents.items():
        (run_path / name).write_bytes(data)

    per_template = Counter(d.template for d in dataset.documents)
    meta = {
        "contract_version": CONTRACT_VERSION,
        "run_id": run_id,
        "synkit_version": __version__,
        "seed": dataset.seed,
        "schema_name": dataset.schema_name,
        "schema_version": dataset.schema_version,
        "generated_at": aware_now.isoformat(timespec="seconds"),
        "counts": {
            "documents": len(dataset.documents),
            "models": len(dataset.models),
            "requirements": len(schema.requirements),
        },
        "templates": [
            {
                "name": t.name,
                "kind": t.kind,
                "layout": t.layout,
                "held_out": t.held_out,
                "documents": per_template[t.name],
            }
            for t in schema.documents.templates
        ],
        "variations": summarize_variations(dataset),
        "files": {name: hashlib.sha256(contents[name]).hexdigest() for name in DATA_FILES},
        "notice": LIMITATION_NOTICE,
    }
    (run_path / "run_meta.json").write_bytes(_json_bytes(meta))
    return RunResult(run_id, run_path)
