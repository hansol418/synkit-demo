from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ProductModel:
    model_id: str
    specs: dict[str, Any]  # requirement id -> 사양 값


@dataclass(frozen=True)
class RequirementValue:
    id: str
    value: Any
    unit: str | None


@dataclass(frozen=True)
class ComplianceResult:
    id: str
    status: str  # Comply / Non-Comply / Partial


@dataclass(frozen=True)
class DisplayItem:
    """문서에 실제로 찍히는 모습. 정답(RequirementValue)과 분리해 채점이 표기에 영향받지 않게 한다."""

    id: str
    present: bool  # False면 문서에서 누락된 항목
    shown_value: Any  # 숫자(환산되었을 수 있음) / 문자열 / 문자열 목록 / None
    shown_unit: str | None  # 문서에 찍힌 단위 문자열(별칭·오타 포함)
    converted_from: str | None  # 환산 단위로 표시했다면 그 단위(예: mA)
    variations: tuple[str, ...] = ()  # unit_alias, unit_converted, value_alias, typo


@dataclass(frozen=True)
class Document:
    doc_id: str
    template: str
    target_model: str
    requirements: tuple[RequirementValue, ...]  # 정답. 누락된 항목은 value가 None
    compliance: tuple[ComplianceResult, ...]  # 누락된 항목은 포함하지 않는다
    language: str = "ko"
    display: tuple[DisplayItem, ...] = ()


@dataclass(frozen=True)
class Dataset:
    seed: int
    schema_name: str
    schema_version: str
    models: tuple[ProductModel, ...]
    documents: tuple[Document, ...]
