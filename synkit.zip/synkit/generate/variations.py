"""표기 변형, 오타, 누락 (F4). docs/decisions.md 19~23번.

원칙: **변형은 표기만 바꾸고 정답은 바꾸지 않는다.**
- 누락: 정답 값을 None으로 두고 적합성에서 뺀다. 문서당 최소 1개는 남긴다.
- 표기 변형: 단위 별칭, 환산 단위(값도 역환산), 선택 값 별칭
- 오타: 단위·선택 값·텍스트 값의 글자에만. 숫자 값에는 넣지 않는다.
"""

from __future__ import annotations

import random
from collections.abc import Sequence
from dataclasses import dataclass

from synkit.generate.models import Dataset, DisplayItem, RequirementValue
from synkit.schema.models import Requirement, Schema, Variations

_MIN_LETTERS = 3


# ---------------------------------------------------------------- 오타

def _letter_positions(text: str) -> list[int]:
    return [i for i, ch in enumerate(text) if ch.isalpha()]


def is_typoable(text: str) -> bool:
    """글자가 3개 이상이어야 오타를 넣을 수 있다. (`V`, `m3/h` 같은 짧은 단위는 제외)"""
    return len(_letter_positions(text)) >= _MIN_LETTERS


def _typo_candidates(text: str, operation: str) -> list[str]:
    letters = _letter_positions(text)
    letter_set = set(letters)
    if operation == "swap":
        return [
            text[:i] + text[i + 1] + text[i] + text[i + 2 :]
            for i in letters
            if i + 1 in letter_set and text[i] != text[i + 1]
        ]
    if operation == "duplicate":
        return [text[: i + 1] + text[i] + text[i + 1 :] for i in letters]
    return [text[:i] + text[i + 1 :] for i in letters]  # drop


def _folded(text: str) -> str:
    """normalize.py의 비교 기준(대소문자·공백 무시)과 같은 형태."""
    return " ".join(text.casefold().split())


def make_typo(rng: random.Random, text: str, forbidden: set[str]) -> str | None:
    """글자 위치 바꾸기, 글자 중복, 글자 빠짐 중 하나로 원문과 1~2 편집거리의 오타를 만든다.

    구분 문자(밑줄, 숫자 등)는 건드리지 않고, 알려진 표기(forbidden)와 같아지는 결과는 피한다.
    만들 수 없으면 None.
    """
    letters = _letter_positions(text)
    if len(letters) < _MIN_LETTERS:
        return None

    operations = ["swap", "duplicate"]
    if len(letters) > _MIN_LETTERS:  # 빠짐은 3글자 미만이 되지 않을 때만
        operations.append("drop")
    rng.shuffle(operations)

    # 정규화(generate/normalize.py)는 대소문자와 공백을 무시하므로, 같은 기준으로 알려진 표기를 피한다.
    # (정확히 같은 문자열만 피하면 `RPMs`에서 `s`를 뺀 `RPM`이 단위 `rpm`으로 해석된다. 9.5 퍼징에서 발견)
    avoided = {_folded(spelling) for spelling in forbidden} | {_folded(text)}

    for operation in operations:
        candidates = _typo_candidates(text, operation)
        rng.shuffle(candidates)
        for candidate in candidates:
            if candidate != text and _folded(candidate) not in avoided:
                return candidate
    return None


# ---------------------------------------------------------------- 표기 변형

def _known_spellings(schema: Schema) -> set[str]:
    known: set[str] = set()
    for req in schema.requirements:
        known.update(req.values or [])
        if req.unit:
            known.add(req.unit)
        for spellings in (req.unit_aliases or {}).values():
            known.update(spellings)
        for spellings in (req.aliases or {}).values():
            known.update(spellings)
        known.update(req.conversions or {})
    return known


def unit_candidates(req: Requirement) -> list[tuple[str, str | None]]:
    """(표시할 단위 문자열, 환산 원본 단위). 정규 단위와 같은 표기는 변형이 아니므로 뺀다."""
    aliases = req.unit_aliases or {}
    candidates: list[tuple[str, str | None]] = [
        (spelling, None) for spelling in aliases.get(req.unit, []) if spelling != req.unit
    ]
    for source in req.conversions or {}:
        candidates += [(spelling, source) for spelling in aliases.get(source, [source])]
    return candidates


def _clean_number(value: float) -> float | int:
    rounded = round(value, 6)
    return int(rounded) if float(rounded).is_integer() else rounded


def _display_number(rng, spec, truth, rates: Variations, known) -> DisplayItem:
    value, unit, converted_from, tags = truth.value, spec.unit, None, []

    candidates = unit_candidates(spec)
    if candidates and rng.random() < rates.unit_notation_rate:
        unit, converted_from = rng.choice(candidates)
        if converted_from:
            conversion = spec.conversions[converted_from]
            value = _clean_number((truth.value - conversion.offset) / conversion.factor)
            tags.append("unit_converted")
        else:
            tags.append("unit_alias")

    if is_typoable(unit) and rng.random() < rates.typo_rate:
        typo = make_typo(rng, unit, known)
        if typo is not None:
            unit = typo
            tags.append("typo")  # 숫자 값은 건드리지 않는다

    return DisplayItem(truth.id, True, value, unit, converted_from, tuple(tags))


def _show_choice(rng, spec, element: str, rates: Variations, known) -> tuple[str, set[str]]:
    tags: set[str] = set()
    shown = element
    alias_list = (spec.aliases or {}).get(element)
    if alias_list and rng.random() < rates.unit_notation_rate:
        shown = rng.choice(alias_list)
        tags.add("value_alias")
    if is_typoable(shown) and rng.random() < rates.typo_rate:
        typo = make_typo(rng, shown, known)
        if typo is not None:
            shown = typo
            tags.add("typo")
    return shown, tags


def _display_choice(rng, spec, truth, rates: Variations, known) -> DisplayItem:
    elements = truth.value if isinstance(truth.value, list) else [truth.value]
    shown_elements, tags = [], set()
    for element in elements:
        shown, element_tags = _show_choice(rng, spec, element, rates, known)
        shown_elements.append(shown)
        tags |= element_tags

    shown_value = shown_elements if isinstance(truth.value, list) else shown_elements[0]
    ordered = tuple(t for t in ("value_alias", "typo") if t in tags)
    return DisplayItem(truth.id, True, shown_value, None, None, ordered)


def _display_text(rng, truth, rates: Variations, known) -> DisplayItem:
    value, tags = truth.value, []
    if is_typoable(value) and rng.random() < rates.typo_rate:
        typo = make_typo(rng, value, known)
        if typo is not None:
            value = typo
            tags.append("typo")
    return DisplayItem(truth.id, True, value, None, None, tuple(tags))


# ---------------------------------------------------------------- 전체 적용

@dataclass(frozen=True)
class VariationResult:
    requirements: tuple[RequirementValue, ...]
    display: tuple[DisplayItem, ...]
    language: str


def apply_variations(
    rng: random.Random, schema: Schema, requirements: Sequence[RequirementValue]
) -> VariationResult:
    rates = schema.documents.variations
    spec = {r.id: r for r in schema.requirements}
    known = _known_spellings(schema)

    language = rng.choice(rates.language_mix)

    # 누락 여부를 먼저 모두 정한다. 다른 변형 비율이 바뀌어도 누락 항목은 같다.
    missing = [rng.random() < rates.missing_rate for _ in requirements]
    if all(missing):
        missing[rng.randrange(len(missing))] = False  # 문서당 최소 1개는 남긴다

    truth_out: list[RequirementValue] = []
    display: list[DisplayItem] = []
    for truth, is_missing in zip(requirements, missing):
        if is_missing:
            truth_out.append(RequirementValue(truth.id, None, truth.unit))
            display.append(DisplayItem(truth.id, False, None, None, None, ()))
            continue

        truth_out.append(truth)
        kind = spec[truth.id].type
        if kind == "number":
            display.append(_display_number(rng, spec[truth.id], truth, rates, known))
        elif kind in ("category", "multi_select"):
            display.append(_display_choice(rng, spec[truth.id], truth, rates, known))
        else:
            display.append(_display_text(rng, truth, rates, known))

    return VariationResult(tuple(truth_out), tuple(display), language)


# ---------------------------------------------------------------- 집계

_NOTATION_TAGS = {"unit_alias", "unit_converted", "value_alias"}


def summarize_variations(dataset: Dataset) -> dict[str, int]:
    items = [item for doc in dataset.documents for item in doc.display]
    return {
        "items": len(items),
        "unit_notation": sum(1 for i in items if _NOTATION_TAGS & set(i.variations)),
        "typo": sum(1 for i in items if "typo" in i.variations),
        "missing": sum(1 for i in items if not i.present),
    }
