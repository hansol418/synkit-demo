"""합성 데이터 생성 코어 (F2, F3, F8).

난수 스트림은 목적별로 분리한다. 문서 수나 기능이 바뀌어도 다른 부분의 데이터가 흔들리지 않는다.
(docs/decisions.md 17번)
"""

from __future__ import annotations

import math
import random

from synkit.generate.compliance import evaluate
from synkit.generate.models import (
    ComplianceResult,
    Dataset,
    Document,
    ProductModel,
    RequirementValue,
)
from synkit.generate.values import sample_for_intent, sample_value
from synkit.generate.variations import apply_variations
from synkit.schema.models import Schema


def _stream(seed: int, purpose: str) -> random.Random:
    return random.Random(f"{seed}:{purpose}")


def _width(count: int, minimum: int) -> int:
    return max(minimum, len(str(count)))


def _generate_models(schema: Schema, seed: int) -> tuple[ProductModel, ...]:
    rng = _stream(seed, "product_db")
    count = schema.product_db.models
    width = _width(count, 2)
    models = []
    for index in range(1, count + 1):
        specs = {req.id: sample_value(rng, req) for req in schema.requirements}
        models.append(ProductModel(f"model_{index:0{width}d}", specs))
    return tuple(models)


def _assign_templates(schema: Schema, seed: int) -> list[str]:
    """양식을 문서에 고르게 배정한다. 한 바퀴마다 순서를 섞어 규칙이 보이지 않게 한다."""
    rng = _stream(seed, "templates")
    names = [t.name for t in schema.documents.templates]
    count = schema.documents.count
    assigned: list[str] = []
    for _ in range(math.ceil(count / len(names))):
        block = names[:]
        rng.shuffle(block)
        assigned += block
    return assigned[:count]


def _generate_document(schema, seed, index, doc_id, template, models) -> Document:
    rng = _stream(seed, f"doc:{index}")
    tolerance = schema.ground_truth.partial_tolerance
    variance = schema.product_db.variance

    target = models[rng.randrange(len(models))]
    requirements: list[RequirementValue] = []
    compliance: list[ComplianceResult] = []

    for req in schema.requirements:
        if req.type == "text":
            value = sample_value(rng, req)
        else:
            gap = rng.random() < variance
            intent = rng.choice(("partial", "non_comply")) if gap else "comply"
            value = sample_for_intent(rng, req, target.specs[req.id], intent, tolerance)

        requirements.append(RequirementValue(req.id, value, req.unit))

        status = evaluate(req, value, target.specs[req.id], tolerance)
        if status is not None:
            compliance.append(ComplianceResult(req.id, status))

    # 변형은 별도 난수 스트림에서 정한다. 위에서 만든 값과 적합성은 바뀌지 않는다. (M3, 결정 21)
    varied = apply_variations(_stream(seed, f"variation:{index}"), schema, requirements)
    missing = {r.id for r in varied.requirements if r.value is None}
    compliance = [c for c in compliance if c.id not in missing]  # 누락 항목은 적합성 정답에서 뺀다

    return Document(
        doc_id, template, target.model_id,
        varied.requirements, tuple(compliance),
        varied.language, varied.display,
    )


def generate_dataset(schema: Schema, *, seed: int | None = None) -> Dataset:
    seed = schema.seed if seed is None else seed
    models = _generate_models(schema, seed)
    templates = _assign_templates(schema, seed)

    count = schema.documents.count
    width = _width(count, 3)
    documents = tuple(
        _generate_document(schema, seed, index, f"rfq_{index:0{width}d}", templates[index - 1], models)
        for index in range(1, count + 1)
    )
    return Dataset(seed, schema.name, schema.version, models, documents)
