"""리포트 데이터 모델. 실행 폴더와 점검·채점 결과 JSON을 읽어 섹션별 데이터로 조립한다. (devplan 7.1)

**표시되는 모든 수치는 원본 JSON(check_result.json, grade_result.json, run_meta.json, schema.yaml)에서 온다.**
이 모듈은 값을 새로 계산하지 않고 고르고 정렬만 한다. (추적성: 리포트의 수치를 원본에서 그대로 찾을 수 있어야 한다)

섹션 순서와 번호는 여기서 정한다. 채점 결과가 없으면 채점 섹션은 **아예 없고**(빈 섹션이 아니다) 번호가 이어진다.
"""

from __future__ import annotations

from typing import Any

from synkit.constants import LIMITATION_NOTICE, SYNTHETIC_TAG
from synkit.run_io import RunData

STATUS_ORDER = ("FAIL", "WARN", "SKIP", "PASS")
MAX_FINDINGS_PER_ITEM = 10

PROVES = [
    "스키마 설정대로 합성 데이터와 정답이 만들어지고, 같은 시드면 같은 데이터가 나온다.",
    "만든 문서를 다시 읽으면 정답이 복원된다. (왕복 검증)",
    "채점기가 알려진 개수의 오류를 정확히 센다. (오답 주입 시험)",
    "점검 항목(제약, 변형 비율, 분포, 안전성, 왕복, 재현성)의 기준에서 이 데이터가 규칙을 지킨다.",
]
DOES_NOT_PROVE = [
    "실제 문서에서의 추출 정확도. 합성 문서에서 높은 점수가 나와도 실제 문서에서도 그렇다는 뜻이 아니다.",
    "실제 문서의 스캔 품질, 비정형 서술, 오류, 표 모양의 다양성. 합성 문서는 정해진 양식 3종과 문장 틀로만 만든다.",
    "보류 양식에서의 일반화 성능. 보류 양식도 같은 생성기가 만든 합성 문서이므로, 격차는 개발 양식에 맞춰 튜닝했는지를 보는 지표일 뿐이다.",
    "수작업 대비 시간 절감. 이것은 별도로 측정한다.",
]
TRANSITION = [
    "스캔·이미지 문서와 문자 인식(OCR) 오류는 만들지 못한다.",
    "자유 문장, 약어, 표 밖의 설명 같은 비정형 서술은 정해진 문장 틀로만 흉내 낸다.",
    "영어 문서에 한국어 단위 별칭(예: 볼트)이 나올 수 있다. 별칭이 문서 언어와 무관하게 선택된다. (설계 결정 24)",
    "실제 문서에서 같은 항목이 여러 곳에 반복되거나 서로 모순되는 경우는 다루지 않는다.",
    "양식은 3종뿐이다. 실제 문서의 양식 다양성은 이보다 훨씬 크다.",
]

_VARIATIONS = (
    ("missing", "누락", "missing_rate"),
    ("unit_notation", "표기 변형", "unit_notation_rate"),
    ("typo", "오타", "typo_rate"),
)
_C2_STATUS = {"ok": "정상 범위", "warn": "범위 밖", "skipped": "표본 부족"}


def _item_by_id(check: dict, item_id: str) -> dict | None:
    return next((i for i in check["items"] if i["id"] == item_id), None)


def _summary(check: dict, grade: dict | None) -> dict[str, Any]:
    ordered = sorted(check["items"], key=lambda i: (STATUS_ORDER.index(i["status"]), i["id"]))
    items = []
    for item in ordered:
        findings = item["findings"]
        items.append({
            "id": item["id"], "name": item["name"], "status": item["status"], "note": item["note"],
            "findings_total": len(findings), "findings": findings[:MAX_FINDINGS_PER_ITEM],
            "findings_hidden": max(0, len(findings) - MAX_FINDINGS_PER_ITEM),
        })
    return {
        "counts": check["summary"],
        "rows": items,
        "partial": len(check["items"]) < 6,
        "has_grade": grade is not None,
    }


def _realism(run: RunData, check: dict) -> dict[str, Any]:
    c2, c3 = _item_by_id(check, "C2"), _item_by_id(check, "C3")
    configured = run.schema.documents.variations

    variations = None
    if c2 is not None:
        variations = []
        for key, label, attribute in _VARIATIONS:
            metric = c2["metrics"].get(key, {})
            variations.append({
                "label": label,
                "configured": getattr(configured, attribute),
                "observed": metric.get("observed_rate"),
                "observed_count": metric.get("observed"),
                "eligible": metric.get("eligible"),
                "status": _C2_STATUS.get(metric.get("status"), "점검 안 함"),
            })

    return {
        "variations": variations,
        "templates": c3["metrics"]["templates"] if c3 else None,
        "compliance": (c3["metrics"].get("compliance") or None) if c3 else None,
        "coverage": c3["metrics"].get("value_coverage") if c3 else None,
        "variance": run.schema.product_db.variance,
    }


def _repro(run: RunData) -> dict[str, Any]:
    meta = run.meta
    return {
        "run_id": run.run_id, "seed": meta["seed"], "schema_name": meta["schema_name"],
        "schema_version": meta["schema_version"], "synkit_version": meta["synkit_version"],
        "contract_version": meta["contract_version"], "generated_at": meta["generated_at"],
        "counts": meta["counts"], "files": meta["files"],
    }


def build_report(run: RunData, check: dict, grade: dict | None) -> dict[str, Any]:
    numbers, next_number = {}, 1
    for key in ("limit", "summary", "grade", "realism", "transition", "repro"):
        if key == "grade" and grade is None:
            numbers[key] = None
            continue
        numbers[key] = next_number
        next_number += 1

    return {
        "title": "합성 데이터 점검·채점 리포트",
        "run_id": run.run_id,
        "schema_name": run.meta["schema_name"],
        "schema_version": run.meta["schema_version"],
        "basis": SYNTHETIC_TAG,
        "notice": LIMITATION_NOTICE,
        "numbers": numbers,
        "proves": PROVES,
        "does_not_prove": DOES_NOT_PROVE,
        "summary": _summary(check, grade),
        "grade": grade,
        "realism": _realism(run, check),
        "transition": TRANSITION,
        "repro": _repro(run),
    }
