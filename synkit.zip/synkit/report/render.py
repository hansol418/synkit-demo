"""리포트 데이터를 Markdown과 단일 파일 HTML로 그린다. (devplan 7.2~7.3)

두 형식 모두 Jinja2 템플릿(report/templates)을 쓴다.
- HTML: 자동 이스케이프를 켠다. CSS는 인라인이고 외부 URL·스크립트·이미지가 없다.
- Markdown: 출력되는 **모든 값**을 `finalize`로 이스케이프한다. (`<`, `>`, `|`, 줄바꿈) 템플릿에서 빠뜨릴 수 없다.
같은 데이터면 같은 결과다. (시각을 새로 만들지 않는다)
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, StrictUndefined

_TEMPLATES = Path(__file__).parent / "templates"
NO_VALUE = "해당 없음"


def pct(value: float | None) -> str:
    return NO_VALUE if value is None else f"{value:.1%}"


def pp(value: float | None) -> str:
    return NO_VALUE if value is None else f"{value * 100:.1f}%p"


def escape_markdown(value: Any) -> str:
    text = str(value).replace("\r", " ").replace("\n", " ")
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("|", "\\|")


def _environment(*, html: bool) -> Environment:
    env = Environment(
        loader=FileSystemLoader(str(_TEMPLATES)),
        autoescape=html,
        finalize=None if html else escape_markdown,
        undefined=StrictUndefined,  # 템플릿이 없는 값을 쓰면 조용히 비우지 않고 실패한다
        trim_blocks=True,
        lstrip_blocks=True,
        keep_trailing_newline=True,
    )
    env.filters.update(pct=pct, pp=pp)
    return env


def render_markdown(data: dict[str, Any]) -> str:
    return _environment(html=False).get_template("report.md.j2").render(**data)


def render_html(data: dict[str, Any]) -> str:
    return _environment(html=True).get_template("report.html.j2").render(**data)
