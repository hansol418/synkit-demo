"""리포트 만들기: 점검·채점 결과를 읽어 report.md와 report.html을 쓴다. (devplan 7.4)

`check_result.json`이 필요하다. `grade_result.json`은 있으면 포함한다. 두 파일이 이 실행의 것인지(run_id)와
지원하는 형식 버전인지 확인한다. 실행 폴더에서 바꾸는 파일은 리포트 두 개뿐이다. (`--out`이면 그 폴더에만 쓴다)

오류 코드: E600 점검 결과 없음 · E601 점검 결과를 쓸 수 없음 · E602 채점 결과를 쓸 수 없음
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

from synkit.report.model import build_report
from synkit.report.render import render_html, render_markdown
from synkit.run_io import RunData
from synkit.schema.issues import Issue, error

SUPPORTED_RESULT_VERSIONS = ("1",)


class ReportError(Exception):
    """리포트를 만들 수 없을 때. 위치·원인·힌트를 가진 Issue 목록을 담는다."""

    def __init__(self, issues: list[Issue]):
        self.issues = list(issues)
        super().__init__("\n".join(f"[오류 {i.code}] {i.location}: {i.cause} (힌트: {i.hint})" for i in self.issues))


@dataclass(frozen=True)
class ReportPaths:
    markdown: Path
    html: Path
    has_grade: bool


def _load(run: RunData, name: str, code: str, hint: str) -> dict:
    path = run.path / name
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ReportError([error(code, name, f"파일을 읽을 수 없습니다. ({type(exc).__name__})", hint)]) from exc
    if not isinstance(data, dict) or data.get("schema_version") not in SUPPORTED_RESULT_VERSIONS:
        raise ReportError([error(
            code, name, f"지원하지 않는 형식입니다. (schema_version: {data.get('schema_version') if isinstance(data, dict) else None!r})",
            f"이 synkit이 읽는 버전은 {', '.join(SUPPORTED_RESULT_VERSIONS)}입니다. {hint}",
        )])
    if data.get("run_id") != run.run_id:
        raise ReportError([error(
            code, name, f"이 실행의 결과가 아닙니다. (run_id: {data.get('run_id')!r}, 실행: {run.run_id})",
            f"다른 실행의 파일을 옮겨 온 것은 아닌지 확인하세요. {hint}",
        )])
    return data


def _write(path: Path, text: str) -> None:
    temp = path.with_name(path.name + ".tmp")
    try:
        temp.write_text(text, encoding="utf-8", newline="\n")
        os.replace(temp, path)
    except BaseException:
        temp.unlink(missing_ok=True)
        raise


def make_report(run: RunData, *, out_dir: str | Path | None = None) -> ReportPaths:
    check_path = run.path / "check_result.json"
    if not check_path.is_file():
        raise ReportError([error(
            "E600", "check_result.json", "점검 결과가 없습니다. 리포트는 점검 결과를 바탕으로 만듭니다.",
            "먼저 `synkit check RUN_DIR`를 실행하세요. 문서 점검까지 보려면 `synkit render RUN_DIR`를 먼저 실행하세요.",
        )])
    check = _load(run, "check_result.json", "E601", "`synkit check RUN_DIR`를 다시 실행하세요.")

    grade = None
    if (run.path / "grade_result.json").is_file():
        grade = _load(run, "grade_result.json", "E602", "`synkit grade RUN_DIR RESULTS.json`을 다시 실행하세요.")

    data = build_report(run, check, grade)
    target = Path(out_dir) if out_dir is not None else run.path
    target.mkdir(parents=True, exist_ok=True)
    paths = ReportPaths(target / "report.md", target / "report.html", grade is not None)
    _write(paths.markdown, render_markdown(data))
    _write(paths.html, render_html(data))
    return paths
