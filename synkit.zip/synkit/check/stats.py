"""C2·C3가 공유하는 통계 기준. (devplan 5.3)

관측 비율이 설정 비율과 "맞는지"를 이항 분포의 허용 범위로 판정한다.
- 범위 = 기대 비율 ± z·σ, σ = √(p(1-p)/n). z = 4.5로 정상 실행에서 거짓 경고가 나올 확률을 사실상 없앤다.
- 비율이 작을 때 이항 분포는 한쪽으로 치우치므로 위쪽에 3/n의 여유(관측 3건 분)를 더한다.
- p가 0이거나 1이면 범위는 정확히 그 값이다. (설정이 0인데 변형이 나오면 이상이다)
- 대상 표본이 MIN_SAMPLE 미만이면 판정하지 않고 "표본 부족"으로 건너뛴다.
"""

from __future__ import annotations

import math

Z = 4.5
MIN_SAMPLE = 30
_UPPER_SLACK_COUNT = 3


def proportion_band(p: float, n: int, *, z: float = Z, shrink: float = 0.0) -> tuple[float, float]:
    """기대 비율 p, 표본 n에서 관측 비율이 들어와야 하는 범위 (낮은 쪽, 높은 쪽).

    shrink는 낮은 쪽만 더 낮춘다. (생성 규칙 때문에 기대보다 덜 나올 수 있을 때: 문서당 최소 1개 유지 등)
    """
    if n <= 0:
        raise ValueError("표본 수는 1 이상이어야 합니다.")
    if p <= 0.0:
        return 0.0, 0.0
    if p >= 1.0:
        return max(0.0, 1.0 - shrink), 1.0
    sigma = math.sqrt(p * (1 - p) / n)
    slack = _UPPER_SLACK_COUNT / n
    return max(0.0, p - z * sigma - slack - shrink), min(1.0, p + z * sigma + slack)
