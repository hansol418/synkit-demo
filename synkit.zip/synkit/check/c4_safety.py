"""C4 안전성. 실행 폴더의 데이터 파일과 `documents/`의 문서 본문에 다음이 없는지 본다. (실패)

  E411 식별자 형식(주민등록번호, Luhn을 통과하는 카드번호, 실제 도메인 이메일, 전화번호, 사업자등록번호)
  E412 절대 경로나 사용자 이름 흔적 (드라이브 경로, UNC, /Users/·/home/ 경로)
  E413 문서에 합성 표시가 없음
  E414 문서를 읽을 수 없어 점검하지 못함

식별자 판정은 스키마 경고(W101)와 같은 `schema.boundary`를 쓴다. 발견 사항에는 **값을 옮겨 적지 않고** 종류만 적는다.
점검 결과가 오히려 식별자를 퍼뜨리면 안 되기 때문이다.
"""

from __future__ import annotations

import csv
import json
import re
from pathlib import Path

import yaml

from synkit.check.doc_text import extract_strings
from synkit.check.result import CheckItem, Finding
from synkit.constants import SYNTHETIC_TOKEN
from synkit.generate.writer import DATA_FILES
from synkit.render.registry import document_filename
from synkit.run_io import RunData
from synkit.schema.boundary import identifier_kind, walk_strings

ITEM_ID = "C4"
NAME = "안전성"

_PATH_PATTERNS = (
    re.compile(r"(?<![A-Za-z0-9])[A-Za-z]:[\\/]"),  # C:\ , D:/
    re.compile(r"\\\\[\w.$-]+\\"),  # \\server\share
    re.compile(r"(?<![\w.])/(?:Users|home)/"),
)
_FILES = DATA_FILES + ("run_meta.json",)
_DATA_HINT = "실행 폴더의 파일을 직접 고치지 말고, 원인이 되는 스키마나 입력을 고친 뒤 `synkit generate`로 새 실행을 만드세요."
_DOC_HINT = "문서에는 가상 값만 있어야 합니다. 렌더러나 스키마를 확인하고 `synkit render --force`로 다시 만드세요."


def _data_strings(path: Path) -> list[tuple[str, str]]:
    """(위치, 문자열) 목록. 형식에 맞게 읽고 읽지 못하면 파일 전체를 한 문자열로 본다."""
    name = path.name
    if name.endswith(".csv"):
        with open(path, encoding="utf-8-sig", newline="") as handle:
            return [(f"{name} {r}행 {c}열", cell) for r, row in enumerate(csv.reader(handle), 1) for c, cell in enumerate(row, 1)]
    text = path.read_text(encoding="utf-8")
    try:
        data = json.loads(text) if name.endswith(".json") else yaml.safe_load(text)
    except (ValueError, yaml.YAMLError):
        return [(name, text)]
    return [(f"{name} {where}" if where else name, value) for where, value in walk_strings(data, "")]


def _scan(location: str, text: str, hint: str, findings: list[Finding], seen: set) -> None:
    kind = identifier_kind(text)
    if kind and (location, "E411") not in seen:
        seen.add((location, "E411"))
        findings.append(Finding("E411", location, f"실제 개인·기업 식별자로 보이는 값({kind})이 있습니다.", hint))
    if any(p.search(text) for p in _PATH_PATTERNS) and (location, "E412") not in seen:
        seen.add((location, "E412"))
        findings.append(Finding(
            "E412", location, "절대 경로나 사용자 이름의 흔적으로 보이는 값이 있습니다.",
            "산출물에는 이 PC의 경로를 쓰지 않습니다(다른 곳으로 옮겨도 같아야 합니다). " + hint,
        ))


def check_safety(run: RunData) -> CheckItem:
    findings: list[Finding] = []
    seen: set = set()
    scanned = 0

    for name in _FILES:
        for location, text in _data_strings(run.path / name):
            scanned += 1
            _scan(location, text, _DATA_HINT, findings, seen)

    documents_dir = run.documents_dir
    documents_scanned = 0
    note = None
    if documents_dir.is_dir():
        templates = {t.name: t for t in run.schema.documents.templates}
        for document in run.dataset.documents:
            template = templates.get(document.template)
            if template is None:
                continue
            name = document_filename(document.doc_id, template)
            path = documents_dir / name
            location = f"documents/{name}"
            if not path.is_file():
                continue  # 파일이 없는 것은 C5가 보고한다
            try:
                text = extract_strings(path)
            except Exception as exc:  # 손상된 파일, 다른 형식
                findings.append(Finding(
                    "E414", location, f"문서를 읽을 수 없어 안전성을 점검하지 못했습니다. ({type(exc).__name__})",
                    _DOC_HINT,
                ))
                continue
            documents_scanned += 1
            for string in text.body + text.properties:
                scanned += 1
                _scan(location, string, _DOC_HINT, findings, seen)
            if not any(s.startswith(SYNTHETIC_TOKEN) for s in text.body):
                findings.append(Finding(
                    "E413", location, f"본문에 합성 표시({SYNTHETIC_TOKEN})가 없습니다.",
                    "모든 문서에는 합성 문서 표시가 있어야 합니다. " + _DOC_HINT,
                ))
    else:
        note = "documents/ 폴더가 없어 문서 본문은 점검하지 않았습니다. (`synkit render` 후 다시 점검하세요)"

    item = CheckItem.build(ITEM_ID, NAME, "FAIL", findings, {"strings_scanned": scanned, "documents_scanned": documents_scanned})
    return CheckItem(item.id, item.name, item.status, item.findings, item.metrics, note)
