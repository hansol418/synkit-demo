"""문서 파일(xlsx, docx)의 문자열을 꺼낸다. C4가 식별자·경로·합성 표시를 점검하는 데 쓴다. (devplan 5.4)

본문(셀, 문단, 표)과 파일 속성을 나눠 돌려준다. 숫자 셀은 문자열이 아니므로 읽지 않는다.
읽을 수 없으면 원래 예외가 그대로 올라간다. (호출한 쪽이 E414로 보고한다)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import docx
import openpyxl


@dataclass(frozen=True)
class ExtractedText:
    body: list[str] = field(default_factory=list)
    properties: list[str] = field(default_factory=list)


def _non_empty(values) -> list[str]:
    return [v for v in values if isinstance(v, str) and v.strip()]


def _from_excel(path: Path) -> ExtractedText:
    workbook = openpyxl.load_workbook(path)
    body = [
        cell.value
        for sheet in workbook.worksheets
        for row in sheet.iter_rows()
        for cell in row
        if isinstance(cell.value, str) and cell.value.strip()
    ]
    p = workbook.properties
    props = _non_empty([p.creator, p.lastModifiedBy, p.title, p.subject, p.keywords, p.description, p.category])
    return ExtractedText(body, props)


def _from_word(path: Path) -> ExtractedText:
    document = docx.Document(str(path))
    body = _non_empty(p.text for p in document.paragraphs)
    for table in document.tables:
        for row in table.rows:
            for cell in row.cells:
                body.extend(_non_empty(p.text for p in cell.paragraphs))
    c = document.core_properties
    props = _non_empty([c.author, c.last_modified_by, c.title, c.subject, c.keywords, c.comments, c.category])
    return ExtractedText(body, props)


def extract_strings(path: str | Path) -> ExtractedText:
    path = Path(path)
    if path.suffix == ".xlsx":
        return _from_excel(path)
    if path.suffix == ".docx":
        return _from_word(path)
    raise ValueError(f"지원하지 않는 문서 형식입니다: {path.suffix!r} (지원: .xlsx, .docx)")
