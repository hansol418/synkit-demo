"""점검 결과 모델과 check_result.json (CK-31-A). devplan 단계 5.

항목(C1~C6)마다 상태를 PASS / WARN / FAIL / SKIP 중 하나로 낸다. 항목의 심각도(severity)는 항목마다 정해져 있고
(C1·C4·C5·C6은 FAIL, C2·C3은 WARN), 발견 사항이 하나라도 있으면 그 심각도가 상태가 된다.
산출물에는 시각과 이 PC의 경로를 넣지 않는다. 같은 실행이면 같은 결과다.

코드: E401~E4xx 실패 발견, W201~W2xx 경고 발견 (항목별 코드는 각 모듈에 있다)
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from synkit.constants import LIMITATION_NOTICE

SCHEMA_VERSION = "1"
SEVERITIES = ("WARN", "FAIL")
STATUSES = ("PASS", "WARN", "FAIL", "SKIP")


@dataclass(frozen=True)
class Finding:
    """발견 사항. 위치·원인·힌트 3요소를 모두 가져야 한다."""

    code: str
    location: str
    cause: str
    hint: str

    def __post_init__(self):
        for name in ("code", "location", "cause", "hint"):
            if not getattr(self, name):
                raise ValueError(f"발견 사항에는 {name}이 있어야 합니다.")


@dataclass(frozen=True)
class CheckItem:
    id: str
    name: str
    status: str
    findings: tuple[Finding, ...] = ()
    metrics: dict[str, Any] = field(default_factory=dict)
    note: str | None = None

    @classmethod
    def build(
        cls, item_id: str, name: str, severity: str, findings: list[Finding],
        metrics: dict[str, Any] | None = None, *, skip: str | None = None,
    ) -> "CheckItem":
        if severity not in SEVERITIES:
            raise ValueError(f"알 수 없는 심각도입니다: {severity!r} (가능: {', '.join(SEVERITIES)})")
        if skip:
            status = "SKIP"
        else:
            status = severity if findings else "PASS"
        return cls(item_id, name, status, tuple(findings), dict(metrics or {}), skip)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "status": self.status,
            "note": self.note,
            "metrics": self.metrics,
            "findings": [
                {"code": f.code, "location": f.location, "cause": f.cause, "hint": f.hint}
                for f in self.findings
            ],
        }


@dataclass(frozen=True)
class CheckResult:
    run_id: str
    contract_version: int
    items: list[CheckItem]

    @property
    def counts(self) -> dict[str, int]:
        return {status: sum(1 for i in self.items if i.status == status) for status in STATUSES}

    @property
    def has_failures(self) -> bool:
        return self.counts["FAIL"] > 0

    @property
    def has_warnings(self) -> bool:
        return self.counts["WARN"] > 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "run_id": self.run_id,
            "contract_version": self.contract_version,
            "notice": LIMITATION_NOTICE,
            "summary": self.counts,
            "items": [i.to_dict() for i in sorted(self.items, key=lambda i: i.id)],
        }

    def write(self, path: str | Path) -> Path:
        """임시 파일에 쓴 뒤 교체한다. 실패하면 기존 파일은 그대로이고 임시 파일은 남지 않는다."""
        path = Path(path)
        temp = path.with_name(path.name + ".tmp")
        text = json.dumps(self.to_dict(), ensure_ascii=False, indent=2) + "\n"
        try:
            temp.write_text(text, encoding="utf-8")
            os.replace(temp, path)
        except BaseException:
            temp.unlink(missing_ok=True)
            raise
        return path
