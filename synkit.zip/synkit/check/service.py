"""점검 실행. 항목(C1~C6)을 고르고 돌려 `check_result.json`을 실행 폴더에 쓴다. (devplan 5.6)

C6(재현성)은 느리므로 `reproduce=True`이거나 `only`에 명시했을 때만 돌린다. 아니면 건너뜀으로 기록한다.
실행 폴더에서 바꾸는 파일은 `check_result.json` 하나뿐이다.
오류 코드: E400 알 수 없는 점검 항목
"""

from __future__ import annotations

from typing import Callable, Sequence

from synkit.check.c1_constraints import check_constraints
from synkit.check.c2_variations import check_variations
from synkit.check.c3_distribution import check_distribution
from synkit.check.c4_safety import check_safety
from synkit.check.c5_roundtrip import check_roundtrip
from synkit.check.c6_reproduce import NAME as C6_NAME, check_reproducibility
from synkit.check.result import CheckItem, CheckResult
from synkit.run_io import RunData
from synkit.schema.issues import Issue, error

RESULT_NAME = "check_result.json"
ALL_ITEMS = ("C1", "C2", "C3", "C4", "C5", "C6")

_RUNNERS: dict[str, Callable[[RunData], CheckItem]] = {
    "C1": check_constraints,
    "C2": check_variations,
    "C3": check_distribution,
    "C4": check_safety,
    "C5": check_roundtrip,
    "C6": check_reproducibility,
}


class CheckError(Exception):
    """점검을 시작할 수 없을 때. 위치·원인·힌트를 가진 Issue 목록을 담는다."""

    def __init__(self, issues: list[Issue]):
        self.issues = list(issues)
        super().__init__("\n".join(f"[오류 {i.code}] {i.location}: {i.cause} (힌트: {i.hint})" for i in self.issues))


def _select(only: Sequence[str] | None) -> list[str]:
    if only is None:
        return list(ALL_ITEMS)
    wanted = [item.strip().upper() for item in only if item.strip()]
    unknown = [item for item in wanted if item not in ALL_ITEMS]
    if unknown or not wanted:
        raise CheckError([error(
            "E400", f"--only {','.join(only)}",
            f"알 수 없는 점검 항목입니다. ({', '.join(unknown) or '비어 있음'})",
            f"사용할 수 있는 항목: {', '.join(ALL_ITEMS)} (쉼표로 여러 개 지정)",
        )])
    return [item for item in ALL_ITEMS if item in wanted]


def run_checks(run: RunData, *, only: Sequence[str] | None = None, reproduce: bool = False) -> CheckResult:
    selected = _select(only)
    items = []
    for item_id in selected:
        if item_id == "C6" and not reproduce and only is None:
            items.append(CheckItem.build(
                "C6", C6_NAME, "FAIL", [], {}, skip="느려서 기본으로는 건너뜁니다. `--reproduce`를 붙이면 점검합니다.",
            ))
            continue
        items.append(_RUNNERS[item_id](run))

    result = CheckResult(run.run_id, run.meta["contract_version"], items)
    result.write(run.path / RESULT_NAME)
    return result
