"""C2 변형 비율. 문서에 실제로 나타난 표기 변형·오타·누락 비율이 스키마 설정과 맞는지 본다.

비율마다 "대상"이 다르다. 대상 중 몇 개에 변형이 걸렸는지를 설정 비율의 허용 범위(check/stats.py)와 비교한다.
  누락      대상 = 모든 항목 (문서당 최소 1개를 남기는 규칙 때문에 낮은 쪽에 그만큼 여유를 둔다)
  표기 변형  대상 = 단위 별칭·환산 후보가 있는 숫자 항목. 선택 값 별칭은 값마다 확률이 겹쳐 대상에서 뺀다.
  오타      대상 = 표시된 단위가 3글자 이상인 숫자 항목과 3글자 이상인 텍스트 항목. 선택 항목은 뺀다.
코드: W201 변형 비율이 설정과 다름
"""

from __future__ import annotations

from synkit.check.result import CheckItem, Finding
from synkit.check.stats import MIN_SAMPLE, proportion_band
from synkit.generate.variations import is_typoable, unit_candidates
from synkit.run_io import RunData

ITEM_ID = "C2"
NAME = "변형 비율"
_NOTATION_TAGS = {"unit_alias", "unit_converted"}
_HINT = "스키마의 documents.variations 설정을 확인하고 `synkit generate`로 다시 생성하세요. 우연이 아니라 생성 규칙 문제일 수 있습니다."


def _evaluate(label: str, rate: float, eligible: int, observed: int, shrink: float, findings: list[Finding]) -> dict:
    metric = {"expected_rate": rate, "eligible": eligible, "observed": observed}
    if eligible < MIN_SAMPLE:
        return {**metric, "status": "skipped"}
    low, high = proportion_band(rate, eligible, shrink=shrink)
    actual = observed / eligible
    metric.update(observed_rate=round(actual, 4), band=[round(low, 4), round(high, 4)])
    if low <= actual <= high:
        return {**metric, "status": "ok"}
    findings.append(Finding(
        "W201", f"document_plan.json ({label})",
        f"{label} 비율이 설정과 맞지 않습니다. (설정 {rate:.1%}, 관측 {actual:.1%} = {observed}/{eligible}, 허용 범위 {low:.1%}~{high:.1%})",
        _HINT,
    ))
    return {**metric, "status": "warn"}


def check_variations(run: RunData) -> CheckItem:
    rates = run.schema.documents.variations
    specs = {r.id: r for r in run.schema.requirements}
    documents = run.dataset.documents

    items = [(spec_item, specs[spec_item.id]) for doc in documents for spec_item in doc.display]
    total = len(items)
    missing = sum(1 for display, _ in items if not display.present)
    keep_one_shrink = len(documents) * rates.missing_rate ** len(specs) / total if total else 0.0

    notation_eligible = [d for d, s in items if d.present and s.type == "number" and unit_candidates(s)]
    notation_observed = sum(1 for d in notation_eligible if _NOTATION_TAGS & set(d.variations))

    typo_eligible = [
        d for d, s in items
        if d.present and (
            (s.type == "number" and d.shown_unit and is_typoable(d.shown_unit))
            or (s.type == "text" and isinstance(d.shown_value, str) and is_typoable(d.shown_value))
        )
    ]
    typo_observed = sum(1 for d in typo_eligible if "typo" in d.variations)

    findings: list[Finding] = []
    metrics = {
        "missing": _evaluate("누락", rates.missing_rate, total, missing, keep_one_shrink, findings),
        "unit_notation": _evaluate(
            "표기 변형", rates.unit_notation_rate, len(notation_eligible), notation_observed, 0.0, findings
        ),
        "typo": _evaluate("오타", rates.typo_rate, len(typo_eligible), typo_observed, 0.0, findings),
    }
    skip = None
    if all(m["status"] == "skipped" for m in metrics.values()):
        skip = f"표본 부족: 모든 비율의 대상이 {MIN_SAMPLE}개 미만이라 판정하지 않았습니다."
    return CheckItem.build(ITEM_ID, NAME, "WARN", findings, metrics, skip=skip)
