"""C3 분포. 합성 데이터가 한쪽으로 치우치거나 퇴화하지 않았는지 본다. (경고)

  양식 배정      양식별 문서 수의 차이가 1 이하여야 한다. (고르게 배정하는 규칙이라 표본 크기와 무관하게 검사)
  선택 값        값이 있는 문서가 MIN_SAMPLE 이상이면, 허용 값이 하나도 안 나오는 것이 없어야 한다.
  숫자 값        값이 있는 문서가 MIN_SAMPLE 이상이면, 값이 범위의 20% 이상을 덮어야 한다. (모두 같은 값 같은 퇴화)
  적합성 분포    `product_db.variance`는 항목이 어긋나게 만들어지는 확률의 상한이다. 어긋남(Comply가 아닌 판정) 비율이
                 variance를 통계 범위로 넘으면 안 되고, variance가 0.05 이상인데 어긋남이 하나도 없으면 안 된다.
코드: W202 분포 이상
"""

from __future__ import annotations

from collections import Counter

from synkit.check.result import CheckItem, Finding
from synkit.check.stats import MIN_SAMPLE, proportion_band
from synkit.run_io import RunData

ITEM_ID = "C3"
NAME = "분포"
_MIN_SPAN = 0.2
_MIN_VARIANCE_TO_EXPECT_GAPS = 0.05
_HINT = "스키마 설정(요구사항 값 범위, 제품 수, variance)을 확인하고 `synkit generate`로 다시 생성하세요."


def _template_findings(run: RunData, findings: list[Finding]) -> dict[str, int]:
    names = [t.name for t in run.schema.documents.templates]
    counts = Counter(d.template for d in run.dataset.documents)
    per_template = {name: counts.get(name, 0) for name in names}
    if len(names) > 1 and max(per_template.values()) - min(per_template.values()) > 1:
        findings.append(Finding(
            "W202", "ground_truth.json (양식 배정)",
            f"양식 배정이 고르지 않습니다. (양식별 문서 수: {per_template})",
            "양식은 고르게 배정되어야 합니다. 생성 규칙 문제일 수 있으니 `synkit generate`로 다시 생성하세요.",
        ))
    return per_template


def check_distribution(run: RunData) -> CheckItem:
    findings: list[Finding] = []
    templates = _template_findings(run, findings)
    documents = run.dataset.documents
    metrics: dict = {"templates": templates, "value_coverage": {}, "compliance": {}}
    skipped_reason = None

    for spec in run.schema.requirements:
        values = [r.value for d in documents for r in d.requirements if r.id == spec.id and r.value is not None]
        if len(values) < MIN_SAMPLE:
            skipped_reason = f"표본 부족: 값이 {MIN_SAMPLE}개 미만인 항목은 분포를 판정하지 않았습니다."
            metrics["value_coverage"][spec.id] = {"status": "skipped", "n": len(values)}
            continue
        location = f"ground_truth.json ({spec.id})"

        if spec.type == "number":
            low, high = spec.range
            span = (max(values) - min(values)) / (high - low) if high > low else 1.0
            metrics["value_coverage"][spec.id] = {"status": "ok", "n": len(values), "span": round(span, 4)}
            if span < _MIN_SPAN:
                metrics["value_coverage"][spec.id]["status"] = "warn"
                findings.append(Finding(
                    "W202", location,
                    f"값이 범위를 고르게 덮지 못합니다. (범위 [{low}, {high}] 중 {span:.0%}만 사용, 서로 다른 값 {len(set(values))}개)",
                    _HINT,
                ))
        elif spec.type in ("category", "multi_select"):
            seen = set()
            for value in values:
                seen.update(value if isinstance(value, list) else [value])
            absent = [v for v in spec.values if v not in seen]
            metrics["value_coverage"][spec.id] = {"status": "warn" if absent else "ok", "n": len(values), "absent": absent}
            if absent:
                findings.append(Finding(
                    "W202", location,
                    f"허용 값 {absent}이 한 번도 나오지 않았습니다. (문서 {len(values)}건 기준)",
                    _HINT,
                ))

    statuses = [c.status for d in documents for c in d.compliance]
    if len(statuses) >= MIN_SAMPLE:
        variance = run.schema.product_db.variance
        gaps = sum(1 for s in statuses if s != "Comply")
        _, high = proportion_band(variance, len(statuses))
        rate = gaps / len(statuses)
        status = "ok"
        location = "ground_truth.json (적합성)"
        if rate > high:
            status = "warn"
            findings.append(Finding(
                "W202", location,
                f"적합성이 Comply가 아닌 비율이 variance({variance:.0%})보다 지나치게 큽니다. (관측 {rate:.1%}, 상한 {high:.1%})",
                _HINT,
            ))
        elif variance >= _MIN_VARIANCE_TO_EXPECT_GAPS and gaps == 0:
            status = "warn"
            findings.append(Finding(
                "W202", location,
                f"variance가 {variance:.0%}인데 Comply가 아닌 적합성이 하나도 없습니다. (Gap이 만들어지지 않았습니다)",
                _HINT,
            ))
        metrics["compliance"] = {
            "status": status, "n": len(statuses), "gap_rate": round(rate, 4), "variance": variance,
            "upper_bound": round(high, 4),
        }
    else:
        metrics["compliance"] = {"status": "skipped", "n": len(statuses)}
        skipped_reason = skipped_reason or f"표본 부족: 적합성이 {MIN_SAMPLE}개 미만이라 분포를 판정하지 않았습니다."

    item = CheckItem.build(ITEM_ID, NAME, "WARN", findings, metrics)
    return CheckItem(item.id, item.name, item.status, item.findings, item.metrics, skipped_reason)
