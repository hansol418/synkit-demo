"""C6 재현성. 실행 폴더의 스키마 사본과 시드로 임시 폴더에 다시 생성해 데이터 파일의 해시를 대조한다. (실패)

같은 시드와 스키마면 데이터 파일은 바이트 단위로 같아야 한다(결정 18). 실행 폴더는 건드리지 않고 임시 폴더는 지운다.
느리므로 `check --reproduce`일 때만 돌린다.

코드
  E431 다시 생성한 파일이 실행 폴더의 파일과 다름
  E432 스키마 사본으로 다시 생성하지 못함
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

from synkit.check.result import CheckItem, Finding
from synkit.generate.core import generate_dataset
from synkit.generate.writer import DATA_FILES, write_run
from synkit.run_io import RunData
from synkit.schema.loader import load_schema_file

ITEM_ID = "C6"
NAME = "재현성"
_HINT = "실행 폴더의 파일을 직접 고치지 말고 `synkit generate`로 새 실행을 만드세요."


def check_reproducibility(run: RunData) -> CheckItem:
    findings: list[Finding] = []
    with tempfile.TemporaryDirectory(prefix="synkit-reproduce-") as temp:
        schema_path = Path(temp) / "schema.yaml"
        schema_path.write_text(run.schema_text, encoding="utf-8")
        loaded = load_schema_file(schema_path)
        if not loaded.ok:
            first = loaded.errors[0]
            findings.append(Finding(
                "E432", "schema.yaml", f"스키마 사본으로 다시 생성하지 못했습니다. ({first.code}: {first.cause})", _HINT,
            ))
            return CheckItem.build(ITEM_ID, NAME, "FAIL", findings, {"files_compared": 0})

        dataset = generate_dataset(loaded.schema, seed=run.dataset.seed)
        again = write_run(dataset, loaded.schema, run.schema_text, Path(temp) / "again")
        fresh = json.loads((again.path / "run_meta.json").read_text(encoding="utf-8"))["files"]

    recorded = run.meta["files"]
    for name in DATA_FILES:
        if fresh.get(name) != recorded.get(name):
            findings.append(Finding(
                "E431", name, "스키마 사본과 시드로 다시 생성한 결과와 다릅니다. (sha256 불일치)",
                "이 실행이 스키마 사본과 시드에서 나온 것이 아니거나, 다른 버전의 synkit이 만든 것일 수 있습니다. " + _HINT,
            ))
    return CheckItem.build(ITEM_ID, NAME, "FAIL", findings, {"files_compared": len(DATA_FILES)})
