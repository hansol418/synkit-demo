"""C5 왕복 정합성. `documents/`가 있으면 문서를 다시 읽어 표시 계획(L1)과 정답(L2)에 대조한다. (실패)

단계 4.7의 `render.roundtrip`을 그대로 재사용한다. 렌더 직후의 검증과 같은 판정을 나중에 다시 하는 것이므로,
렌더 뒤에 문서를 사람이 고쳤거나 다른 버전의 synkit이 만든 경우를 잡는다. 또 manifest.json의 파일 해시를 대조한다.
`render --only`로 일부만 만든 경우는 manifest의 `only`에 든 양식만 점검한다.

코드
  E421 문서가 표시 계획(L1) 또는 정답(L2)과 다름
  E422 manifest.json이 없거나 실행·파일 해시와 맞지 않음
  E423 문서 파일이 없음
  E424 문서를 읽을 수 없음
"""

from __future__ import annotations

import hashlib
import json

from synkit.check.result import CheckItem, Finding
from synkit.render.registry import document_filename, roundtrip_document
from synkit.render.roundtrip import ParseError
from synkit.run_io import RunData

ITEM_ID = "C5"
NAME = "왕복 정합성"
_HINT = "문서를 직접 고치지 말고 `synkit render --force`로 다시 만드세요."


def _read_manifest(run: RunData, findings: list[Finding]) -> dict | None:
    path = run.documents_dir / "manifest.json"
    location = "documents/manifest.json"
    if not path.is_file():
        findings.append(Finding("E422", location, "manifest.json이 없습니다.", _HINT))
        return None
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, UnicodeDecodeError):
        findings.append(Finding("E422", location, "manifest.json을 읽을 수 없습니다.", _HINT))
        return None
    if not isinstance(manifest, dict) or manifest.get("run_id") != run.run_id:
        findings.append(Finding(
            "E422", location, "manifest.json이 이 실행의 것이 아닙니다. (run_id가 다릅니다)",
            "다른 실행의 documents 폴더를 옮겨 온 것은 아닌지 확인하고 " + _HINT,
        ))
        return None
    return manifest


def check_roundtrip(run: RunData) -> CheckItem:
    if not run.documents_dir.is_dir():
        return CheckItem.build(
            ITEM_ID, NAME, "FAIL", [], {"documents": 0},
            skip="documents/ 폴더가 없어 점검하지 않았습니다. `synkit render` 후 다시 점검하세요.",
        )

    findings: list[Finding] = []
    manifest = _read_manifest(run, findings)
    only = manifest.get("only") if manifest else None
    hashes = {e.get("file"): e.get("sha256") for e in (manifest or {}).get("documents", []) if isinstance(e, dict)}
    templates = {t.name: t for t in run.schema.documents.templates}
    metrics = {"documents": 0, "l1_mismatches": 0, "l2_mismatches": 0}

    for document in run.dataset.documents:
        template = templates.get(document.template)
        if template is None or (only is not None and document.template not in only):
            continue
        name = document_filename(document.doc_id, template)
        path = run.documents_dir / name
        location = f"documents/{name}"
        metrics["documents"] += 1

        if not path.is_file():
            findings.append(Finding("E423", location, "문서 파일이 없습니다.", _HINT))
            continue
        if name in hashes and hashes[name] != hashlib.sha256(path.read_bytes()).hexdigest():
            findings.append(Finding(
                "E422", location, "파일이 manifest.json에 기록된 해시와 다릅니다. (렌더 뒤에 파일이 바뀌었습니다)", _HINT,
            ))
        try:
            result = roundtrip_document(path, run.schema, template, document)
        except ParseError as exc:
            findings.append(Finding("E424", location, f"문서를 읽을 수 없습니다. ({exc.issue.cause})", _HINT))
            continue
        except Exception as exc:  # 손상된 파일 등
            findings.append(Finding("E424", location, f"문서를 읽을 수 없습니다. ({type(exc).__name__})", _HINT))
            continue

        for layer, mismatches in (("l1", result.l1), ("l2", result.l2.mismatches)):
            metrics[f"{layer}_mismatches"] += len(mismatches)
            for m in mismatches:
                what = "표시 계획" if layer == "l1" else "정답"
                findings.append(Finding(
                    "E421", f"{location} {m.requirement_id or '-'}",
                    f"문서가 {what}과 다릅니다. (필드 {m.field}: 기대 {m.expected!r}, 실제 {m.actual!r})", _HINT,
                ))

    return CheckItem.build(ITEM_ID, NAME, "FAIL", findings, metrics)
