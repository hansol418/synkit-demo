"""C1 제약 위반. 정답 값·제품 사양이 스키마의 규칙을 지키는지, 기록된 적합성이 다시 계산한 값과 같은지 전수 검사한다.

허용 오차는 0이다. 코드
  E401 정답 값이 유형·범위·허용 값·단위를 어김
  E402 제품 사양 값이 범위·허용 값을 어김
  E403 적합성이 다시 계산한 값과 다름 (누락 항목에 적합성이 있거나, 있어야 할 적합성이 없는 경우 포함)
  E404 문서의 양식 이름이나 대상 제품 모델을 알 수 없음
"""

from __future__ import annotations

from typing import Any

from synkit.check.result import CheckItem, Finding
from synkit.generate.compliance import evaluate
from synkit.run_io import RunData
from synkit.schema.models import Requirement

ITEM_ID = "C1"
NAME = "제약 위반"
_REGENERATE = "실행 폴더를 직접 고치지 말고 `synkit generate`로 새 실행을 만드세요."


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def value_problem(spec: Requirement, value: Any) -> str | None:
    """값이 요구사항 정의를 어기면 이유를, 지키면 None을 돌려준다."""
    if spec.type == "number":
        if not _is_number(value):
            return f"숫자여야 하는데 {value!r}입니다."
        low, high = spec.range
        if not low <= value <= high:
            return f"값 {value}가 범위 [{low}, {high}] 밖입니다."
    elif spec.type == "category":
        if value not in spec.values:
            return f"값 {value!r}가 허용 값 {spec.values}에 없습니다."
    elif spec.type == "multi_select":
        if not isinstance(value, list):
            return f"목록이어야 하는데 {value!r}입니다."
        unknown = [v for v in value if v not in spec.values]
        if unknown:
            return f"허용 값 {spec.values}에 없는 항목 {unknown}이 있습니다."
    elif spec.type == "text":
        if not isinstance(value, str):
            return f"문자열이어야 하는데 {value!r}입니다."
    return None


def check_constraints(run: RunData) -> CheckItem:
    schema = run.schema
    specs = {r.id: r for r in schema.requirements}
    models = {m.model_id: m for m in run.dataset.models}
    templates = {t.name for t in schema.documents.templates}
    tolerance = schema.ground_truth.partial_tolerance
    findings: list[Finding] = []
    metrics = {"documents": len(run.dataset.documents), "values_checked": 0, "compliance_checked": 0, "product_values_checked": 0}

    for model in run.dataset.models:
        for requirement_id, value in model.specs.items():
            metrics["product_values_checked"] += 1
            problem = value_problem(specs[requirement_id], value)
            if problem:
                findings.append(Finding(
                    "E402", f"product_db.csv {model.model_id}/{requirement_id}", problem,
                    f"제품 사양은 스키마의 범위·허용 값 안이어야 합니다. {_REGENERATE}",
                ))

    for doc in run.dataset.documents:
        if doc.template not in templates:
            findings.append(Finding(
                "E404", f"ground_truth.json {doc.doc_id}", f"스키마에 없는 양식 이름입니다. ({doc.template})",
                f"스키마의 양식 이름({', '.join(sorted(templates))}) 중 하나여야 합니다. {_REGENERATE}",
            ))
        model = models.get(doc.target_model)
        if model is None:
            findings.append(Finding(
                "E404", f"ground_truth.json {doc.doc_id}", f"제품 DB에 없는 대상 모델입니다. ({doc.target_model})",
                f"대상 모델은 product_db.csv의 model_id여야 합니다. {_REGENERATE}",
            ))

        recorded = {c.id: c.status for c in doc.compliance}
        for requirement in doc.requirements:
            spec = specs[requirement.id]
            location = f"ground_truth.json {doc.doc_id}/{requirement.id}"

            if requirement.value is not None:
                metrics["values_checked"] += 1
                problem = value_problem(spec, requirement.value)
                if problem:
                    findings.append(Finding("E401", location, problem, f"정답 값은 스키마 정의를 지켜야 합니다. {_REGENERATE}"))
                if spec.type == "number" and requirement.unit != spec.unit:
                    findings.append(Finding(
                        "E401", location, f"단위가 스키마와 다릅니다. (기록: {requirement.unit!r}, 스키마: {spec.unit!r})",
                        f"정답의 단위는 스키마의 단위와 같아야 합니다. {_REGENERATE}",
                    ))

            expected = None
            if requirement.value is not None and model is not None and not findings_for(findings, location, "E401"):
                expected = evaluate(spec, requirement.value, model.specs[requirement.id], tolerance)
            actual = recorded.get(requirement.id)
            if requirement.value is None or spec.type == "text":
                if actual is not None:
                    findings.append(Finding(
                        "E403", location, f"적합성이 없어야 하는 항목에 {actual}이 기록되어 있습니다.",
                        f"누락 항목과 텍스트 항목은 적합성 정답에 없어야 합니다. {_REGENERATE}",
                    ))
                continue
            if expected is None:  # 값 오류로 다시 계산할 수 없음 (E401이 이미 보고됨)
                continue
            metrics["compliance_checked"] += 1
            if actual != expected:
                findings.append(Finding(
                    "E403", location, f"기록된 적합성({actual})이 다시 계산한 값({expected})과 다릅니다.",
                    f"적합성은 판정 함수로 계산한 값이어야 합니다. {_REGENERATE}",
                ))

    return CheckItem.build(ITEM_ID, NAME, "FAIL", findings, metrics)


def findings_for(findings: list[Finding], location: str, code: str) -> bool:
    return any(f.location == location and f.code == code for f in findings)
