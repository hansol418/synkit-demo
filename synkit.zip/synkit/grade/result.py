"""채점 결과 모델과 grade_result.json (GR-36-A). devplan 단계 6.

산출물에는 시각과 이 PC의 경로를 넣지 않는다. 같은 실행과 같은 제출물이면 같은 결과다.

코드 (명세 docs/specs/GRADE_INPUT_SPEC.md의 입력 검증 표)
  중단: E500 제출 파일을 읽을 수 없음 · E501 schema_version 없음·불일치 · E502 최상위 구조가 다름
  문서 단위: E510 doc_id가 이 실행에 없음 · E511 results 항목에 doc_id가 없음 · E512 requirements가 목록이 아님
             E513 requirements 항목 형식이 다름 · E514 compliance가 목록이 아님
  항목 단위(형식 오류로 오답 처리): E520 숫자에 unit 없음 · E521 정의되지 않은 단위·별칭 · E522 값의 유형이 다름
                                  E523 적합성 판정 값이 올바르지 않음
  경고: W501 run_id 불일치 · W502 정의되지 않은 요구사항 id · W503 정답 문서가 results에 없음
        W504 중복(문서 또는 항목) · W505 적합성 정답이 없는 id에 판정이 있음
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from synkit.schema.issues import Issue

SCHEMA_VERSION = "1"
SUPPORTED_INPUT_VERSIONS = ("1",)


class GradeError(Exception):
    """채점을 시작할 수 없을 때. 위치·원인·힌트를 가진 Issue 목록을 담는다."""

    def __init__(self, issues: list[Issue]):
        self.issues = list(issues)
        super().__init__("\n".join(f"[오류 {i.code}] {i.location}: {i.cause} (힌트: {i.hint})" for i in self.issues))


@dataclass(frozen=True)
class GradeResult:
    data: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return self.data

    @property
    def issues(self) -> list[dict[str, str]]:
        return self.data["issues"]

    def write(self, path: str | Path) -> Path:
        """임시 파일에 쓴 뒤 교체한다. 실패하면 기존 파일은 그대로이고 임시 파일은 남지 않는다."""
        path = Path(path)
        temp = path.with_name(path.name + ".tmp")
        text = json.dumps(self.data, ensure_ascii=False, indent=2) + "\n"
        try:
            temp.write_text(text, encoding="utf-8")
            os.replace(temp, path)
        except BaseException:
            temp.unlink(missing_ok=True)
            raise
        return path
