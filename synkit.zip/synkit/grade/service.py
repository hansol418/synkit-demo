"""제출 파일을 읽어 채점하고 `grade_result.json`을 실행 폴더에 쓴다. (devplan 6.6)

실행 폴더에서 바꾸는 파일은 `grade_result.json` 하나뿐이다. 채점 중단 오류(E500~E502)가 나면 아무것도 쓰지 않는다.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from synkit.constants import GRADE_HISTORY_DIR, GRADE_HISTORY_HASH_LENGTH
from synkit.grade.engine import grade_submission
from synkit.grade.result import GradeError, GradeResult
from synkit.run_io import RunData
from synkit.schema.issues import error

RESULT_NAME = "grade_result.json"


def load_submission(path: str | Path):
    path = Path(path)
    try:
        text = path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeDecodeError) as exc:
        raise GradeError([error(
            "E500", str(path.name), f"제출 파일을 읽을 수 없습니다. ({type(exc).__name__})",
            "추출 결과 JSON(UTF-8) 파일 경로를 확인하세요. 형식은 docs/specs/GRADE_INPUT_SPEC.md에 있습니다.",
        )]) from exc
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise GradeError([error(
            "E500", f"{path.name}:{exc.lineno}행 {exc.colno}열", f"JSON 형식이 올바르지 않습니다. ({exc.msg})",
            "JSON 문법(따옴표, 쉼표, 괄호)을 확인하세요.",
        )]) from exc


def grade_run(run: RunData, results_path: str | Path, name: str | None = None) -> GradeResult:
    """채점해 `grade_result.json`(최신)과 `grades/<제출물 해시 앞 12자>.json`(이력)에 쓴다. (ADR 0008)

    같은 제출물로 다시 채점하면 이력 파일을 덮어쓰므로 파일이 늘어나는 것은 서로 다른 제출물일 때뿐이다.
    제출물 해시는 제출 파일의 바이트로 계산한다. 채점이 실패하면 아무것도 쓰지 않는다.
    """
    results_path = Path(results_path)
    submission = load_submission(results_path)
    digest = hashlib.sha256(results_path.read_bytes()).hexdigest()
    result = grade_submission(
        run, submission, submission={"results_sha256": digest, "name": name or results_path.stem},
    )
    result.write(run.path / RESULT_NAME)
    history = run.path / GRADE_HISTORY_DIR
    history.mkdir(exist_ok=True)
    result.write(history / f"{digest[:GRADE_HISTORY_HASH_LENGTH]}.json")
    return result
