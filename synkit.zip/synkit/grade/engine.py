"""채점 엔진. 제출물(추출 결과)을 정답과 대조해 항목별로 분류하고 집계한다. (devplan 6.1~6.5)

기준은 docs/specs/GRADE_INPUT_SPEC.md다. 정규화는 생성기가 쓰는 규칙의 역함수(`generate.normalize`)를 그대로 쓴다.
이 모듈은 파일을 읽지 않는다. 제출물은 이미 JSON으로 읽은 값(data)을 받는다. (읽기는 service.py)

항목 분류 (정답 항목마다 정확히 하나)
  correct          값이 정답과 같음                                  맞음
  correct_absent   정답이 '없음'(누락)이고 못 찾았다고 보고            맞음
  mispredicted     값이 있으나 정답과 다름                           틀림 (오추출)
  missed           정답이 있는데 못 찾았다고 보고(생략·null)          틀림 (미검출)
  hallucinated     정답이 '없음'인데 값을 채움                        틀림 (환각)
  format_error     형식이 어긋나 비교할 수 없음                       틀림 (E520~E522)
"""

from __future__ import annotations

from collections import Counter
from typing import Any

from synkit.constants import LIMITATION_NOTICE
from synkit.generate.normalize import UnknownNotation, normalize_shown
from synkit.grade.result import SCHEMA_VERSION, SUPPORTED_INPUT_VERSIONS, GradeError, GradeResult
from synkit.run_io import RunData
from synkit.schema.issues import Issue, error, warning
from synkit.schema.models import Requirement

ERROR_KINDS = ("mispredicted", "missed", "hallucinated", "format_error")
CORRECT_KINDS = ("correct", "correct_absent")
STATUSES = ("Comply", "Non-Comply", "Partial")
BASIS = "합성 데이터 기준 (실성능 아님)"
_NUMBER_TOLERANCE = 1e-9  # 부동소수점 표현 오차. 허용 오차가 아니다. (명세: 상대 1e-9 이내는 같은 값)

_VERSION_HINT = f"지원하는 버전은 {', '.join(SUPPORTED_INPUT_VERSIONS)}입니다. 최상위에 \"schema_version\": \"1\"을 쓰세요."


# ---------------------------------------------------------------- 항목 하나의 분류

def _same_number(actual: float, expected: float) -> bool:
    return abs(actual - expected) <= _NUMBER_TOLERANCE * max(1.0, abs(expected))


def _classify_present(spec: Requirement, expected: Any, entry: dict, location: str):
    """정답이 있는 항목에 값이 제출된 경우. (분류, Issue 또는 None)"""
    value, unit = entry.get("value"), entry.get("unit")

    if spec.type == "number" and (isinstance(value, bool) or not isinstance(value, (int, float))):
        return "format_error", error("E522", location, f"숫자 항목의 값이 숫자가 아닙니다. ({value!r})", "`value`에 숫자를 쓰세요. (문자열이 아닙니다)")
    if spec.type == "number" and unit is None:
        return "format_error", error("E520", location, "숫자 항목에 단위(`unit`)가 없습니다.", f"`unit`을 추가하세요. (정규 단위는 {spec.unit})")
    if spec.type == "text" and not isinstance(value, str):
        return "format_error", error("E522", location, f"텍스트 항목의 값이 문자열이 아닙니다. ({value!r})", "`value`에 문자열을 쓰세요.")

    try:
        normalized = normalize_shown(spec, value, unit if isinstance(unit, str) or unit is None else str(unit))
    except UnknownNotation as exc:
        hint = ("스키마의 `unit_aliases` 또는 `conversions`에 이 단위를 추가하거나 문서의 단위 표기대로 쓰세요."
                if spec.type == "number" else "스키마의 `aliases`(또는 `values`)에 이 표기를 추가하거나 정규 값을 쓰세요.")
        return "format_error", error("E521", location, f"스키마에 정의되지 않은 표기입니다. ({exc})", hint)
    except TypeError as exc:
        return "format_error", error("E522", location, f"값의 유형이 요구사항과 다릅니다. ({exc})", "스키마의 유형(숫자, 선택, 목록, 텍스트)에 맞춰 쓰세요.")

    if spec.type == "number":
        same = _same_number(normalized, expected)
    elif spec.type == "multi_select":
        same = set(normalized) == set(expected)
    else:
        same = normalized == expected
    return ("correct" if same else "mispredicted"), None


def classify_item(spec: Requirement, expected: Any, entry: dict | None, location: str):
    """(분류, Issue 또는 None). entry는 제출된 항목(dict)이거나 None(키 생략)."""
    submitted = entry.get("value") if entry else None
    if expected is None:
        return ("correct_absent" if submitted is None else "hallucinated"), None
    if submitted is None:
        return "missed", None
    return _classify_present(spec, expected, entry, location)


# ---------------------------------------------------------------- 집계 도우미

def _ratio(correct: int, total: int) -> float | None:
    return round(correct / total, 6) if total else None


def _empty_errors() -> dict[str, int]:
    return dict.fromkeys(ERROR_KINDS, 0)


def _issue_dict(issue: Issue) -> dict[str, str]:
    return {"severity": issue.severity, "code": issue.code, "location": issue.location, "cause": issue.cause, "hint": issue.hint}


def _tags_of(display) -> list[str]:
    if not display.present:
        return ["missing"]
    return list(display.variations) or ["none"]


# ---------------------------------------------------------------- 제출물 읽기

def _validate_top(run: RunData, data: Any) -> list[Any]:
    if not isinstance(data, dict):
        raise GradeError([error("E502", "(최상위)", "최상위가 JSON 객체가 아닙니다.", "명세의 형식(`schema_version`, `results`)대로 객체로 쓰세요.")])
    version = data.get("schema_version")
    if version not in SUPPORTED_INPUT_VERSIONS:
        raise GradeError([error(
            "E501", "schema_version",
            "`schema_version`이 없습니다." if version is None else f"지원하지 않는 버전입니다. ({version!r})", _VERSION_HINT,
        )])
    if not isinstance(data.get("results"), list):
        raise GradeError([error("E502", "results", "`results`가 없거나 목록이 아닙니다.", "문서별 결과의 배열을 `results`에 쓰세요.")])
    return data["results"]


def _index_documents(run: RunData, results: list, issues: list[Issue]) -> dict[str, dict]:
    known = {d.doc_id for d in run.dataset.documents}
    by_id: dict[str, dict] = {}
    for index, entry in enumerate(results):
        location = f"results[{index}]"
        if not isinstance(entry, dict) or not isinstance(entry.get("doc_id"), str):
            issues.append(error("E511", location, "`doc_id`가 없거나 항목이 객체가 아닙니다.", "문서마다 `doc_id`를 쓰세요. 이 항목은 채점하지 않았습니다."))
        elif entry["doc_id"] not in known:
            issues.append(error(
                "E510", f"{location}.doc_id", f"이 실행에 없는 문서입니다. ({entry['doc_id']})",
                "`generate`가 만든 문서 ID(문서 파일명에서 확장자를 뺀 값)를 쓰세요. 이 문서는 채점하지 않았습니다.",
            ))
        elif entry["doc_id"] in by_id:
            issues.append(warning("W504", f"{location}.doc_id", f"같은 문서가 중복되어 있습니다. ({entry['doc_id']})", "첫 번째 항목만 채점했습니다. 중복을 지우세요."))
        else:
            by_id[entry["doc_id"]] = entry
    return by_id


def _index_requirements(doc_id: str, sub: dict, spec_ids: set[str], issues: list[Issue]) -> dict[str, dict]:
    requirements = sub.get("requirements")
    if not isinstance(requirements, list):
        issues.append(error("E512", f"results[{doc_id}].requirements", "`requirements`가 없거나 목록이 아닙니다.", "추출한 요구사항의 배열을 쓰세요. 이 문서의 항목은 모두 못 찾은 것으로 처리했습니다."))
        return {}
    entries: dict[str, dict] = {}
    for index, entry in enumerate(requirements):
        location = f"results[{doc_id}].requirements[{index}]"
        if not isinstance(entry, dict) or not isinstance(entry.get("id"), str):
            issues.append(error("E513", location, "항목이 객체가 아니거나 `id`가 없습니다.", "`{\"id\": ..., \"value\": ...}` 형식으로 쓰세요. 이 항목은 채점하지 않았습니다."))
        elif entry["id"] not in spec_ids:
            issues.append(warning("W502", location, f"스키마에 정의되지 않은 항목입니다. ({entry['id']})", "스키마의 요구사항 id를 쓰세요. 이 항목은 점수에 넣지 않았습니다."))
        elif entry["id"] in entries:
            issues.append(warning("W504", location, f"같은 항목이 중복되어 있습니다. ({entry['id']})", "첫 번째 항목만 채점했습니다. 중복을 지우세요."))
        else:
            entries[entry["id"]] = entry
    return entries


def _grade_compliance(doc, sub: dict, issues: list[Issue]) -> tuple[int, int, bool]:
    """(맞은 수, 전체 수, 이 문서가 적합성을 제출했는가). 명세: 배열이 있으면 모든 정답 id가 채점 대상이다."""
    if "compliance" not in sub:
        return 0, 0, False
    submitted = sub["compliance"]
    location = f"results[{doc.doc_id}].compliance"
    if not isinstance(submitted, list):
        issues.append(error("E514", location, "`compliance`가 목록이 아닙니다.", "`[{\"id\": ..., \"status\": ...}]` 형식으로 쓰세요. 이 문서의 적합성은 채점하지 않았습니다."))
        return 0, 0, False

    truth = {c.id: c.status for c in doc.compliance}
    given: dict[str, Any] = {}
    for index, entry in enumerate(submitted):
        if not isinstance(entry, dict) or not isinstance(entry.get("id"), str):
            issues.append(error("E513", f"{location}[{index}]", "항목이 객체가 아니거나 `id`가 없습니다.", "`{\"id\": ..., \"status\": ...}` 형식으로 쓰세요."))
        elif entry["id"] not in truth:
            issues.append(warning("W505", f"{location}[{index}]", f"적합성 정답이 없는 항목입니다. ({entry['id']})", "누락된 항목과 텍스트 항목에는 판정이 없습니다. 이 판정은 점수에 넣지 않았습니다."))
        elif entry["id"] not in given:
            given[entry["id"]] = entry.get("status")

    correct = 0
    for requirement_id, expected in truth.items():
        status = given.get(requirement_id)
        if requirement_id in given and status not in STATUSES:
            issues.append(error("E523", f"{location}[{requirement_id}]", f"판정 값이 올바르지 않습니다. ({status!r})", f"`status`는 {', '.join(STATUSES)} 중 하나여야 합니다. 이 판정은 오답으로 처리했습니다."))
        elif status == expected:
            correct += 1
    return correct, len(truth), True


# ---------------------------------------------------------------- 채점

def grade_submission(run: RunData, data: Any, *, submission: dict[str, str] | None = None) -> GradeResult:
    """`submission`은 제출물 해시·이름처럼 채점 이력을 식별하는 값이다. 있으면 결과의 `input`에 그대로 기록한다."""
    results = _validate_top(run, data)
    issues: list[Issue] = []
    specs = {r.id: r for r in run.schema.requirements}
    templates = list(run.schema.documents.templates)
    held_out = {t.name: t.held_out for t in templates}

    if "run_id" in data and data["run_id"] != run.run_id:
        issues.append(warning(
            "W501", "run_id", f"제출물의 run_id({data['run_id']!r})가 채점 대상 실행({run.run_id})과 다릅니다.",
            "다른 실행의 문서에서 추출한 결과가 아닌지 확인하세요. 채점은 계속했습니다.",
        ))

    by_doc = _index_documents(run, results, issues)
    records = []  # (템플릿, 요구사항 id, 태그, 분류, 문서 번호)
    details = []
    per_doc_ok: dict[str, bool] = {}
    compliance_total = compliance_correct = compliance_docs = documents_missing = 0

    for doc in run.dataset.documents:
        sub = by_doc.get(doc.doc_id)
        if sub is None:
            documents_missing += 1
            issues.append(warning(
                "W503", f"results[{doc.doc_id}]", "정답 문서가 results에 없습니다.",
                "이 문서의 정답이 있는 항목은 모두 미검출로 처리했습니다. 추출 대상에 이 문서가 빠졌는지 확인하세요.",
            ))
            entries: dict[str, dict] = {}
        else:
            entries = _index_requirements(doc.doc_id, sub, set(specs), issues)
            correct, total, provided = _grade_compliance(doc, sub, issues)
            compliance_correct, compliance_total, compliance_docs = (
                compliance_correct + correct, compliance_total + total, compliance_docs + provided,
            )

        display = {d.id: d for d in doc.display}
        all_correct = True
        for item in doc.requirements:
            location = f"results[{doc.doc_id}].requirements[{item.id}]"
            kind, issue = classify_item(specs[item.id], item.value, entries.get(item.id), location)
            if issue:
                issues.append(issue)
            records.append((doc.template, item.id, _tags_of(display[item.id]), kind))
            if kind in ERROR_KINDS:
                all_correct = False
                entry = entries.get(item.id) or {}
                details.append({
                    "doc_id": doc.doc_id, "requirement_id": item.id, "template": doc.template, "class": kind,
                    "expected": item.value, "actual": {"value": entry.get("value"), "unit": entry.get("unit")} if entry else None,
                })
        per_doc_ok[doc.doc_id] = all_correct

    # ---- 집계
    def tally(selected) -> dict[str, Any]:
        counts = Counter(kind for *_, kind in selected)
        total = sum(counts.values())
        correct = sum(counts[k] for k in CORRECT_KINDS)
        return {
            "items_total": total, "items_correct": correct, "item_accuracy": _ratio(correct, total),
            "errors": {k: counts[k] for k in ERROR_KINDS},
        }

    summary = tally(records)
    documents_exact = sum(per_doc_ok.values())
    summary.update(
        documents_total=len(per_doc_ok), documents_exact=documents_exact,
        document_exact_rate=_ratio(documents_exact, len(per_doc_ok)),
        compliance={
            "documents": compliance_docs, "total": compliance_total, "correct": compliance_correct,
            "accuracy": _ratio(compliance_correct, compliance_total),
        },
    )

    docs_by_template = Counter(d.template for d in run.dataset.documents)
    exact_by_template = Counter(d.template for d in run.dataset.documents if per_doc_ok[d.doc_id])
    by_template = [
        {
            "name": t.name, "held_out": t.held_out, "documents": docs_by_template[t.name],
            "documents_exact": exact_by_template[t.name],
            "document_exact_rate": _ratio(exact_by_template[t.name], docs_by_template[t.name]),
            **tally([r for r in records if r[0] == t.name]),
        }
        for t in templates
    ]
    by_requirement = [{"id": rid, **tally([r for r in records if r[1] == rid])} for rid in specs]

    by_variation: dict[str, Any] = {}
    for tag in sorted({tag for r in records for tag in r[2]}):
        selected = [r for r in records if tag in r[2]]
        stats = tally(selected)
        by_variation[tag] = {k: stats[k] for k in ("items_total", "items_correct", "item_accuracy")}

    development = tally([r for r in records if not held_out[r[0]]])
    reserved = tally([r for r in records if held_out[r[0]]])
    gap = None
    if development["items_total"] and reserved["items_total"]:
        gap = {
            "development_accuracy": development["item_accuracy"], "held_out_accuracy": reserved["item_accuracy"],
            "gap": round(development["item_accuracy"] - reserved["item_accuracy"], 6),
        }

    return GradeResult({
        "schema_version": SCHEMA_VERSION,
        "run_id": run.run_id,
        "contract_version": run.meta["contract_version"],
        "basis": BASIS,
        "notice": LIMITATION_NOTICE,
        "input": {
            "documents_in_run": len(run.dataset.documents),
            "documents_graded": len(run.dataset.documents) - documents_missing,
            "documents_missing": documents_missing,
            "compliance_documents": compliance_docs,
            **(submission or {}),
        },
        "summary": summary,
        "by_template": by_template,
        "by_requirement": by_requirement,
        "by_variation": by_variation,
        "held_out_gap": gap,
        "issues": [_issue_dict(i) for i in issues],
        "errors_detail": details,
    })
