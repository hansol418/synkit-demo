"""스키마 검증 결과 표현.

모든 오류와 경고는 **위치·원인·해결 힌트** 세 요소를 가진다. (IA의 공통 오류 메시지 형식)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from synkit.schema.models import Schema

Severity = Literal["error", "warning"]


@dataclass(frozen=True)
class Issue:
    severity: Severity
    code: str
    location: str
    cause: str
    hint: str


@dataclass
class LoadResult:
    schema: Schema | None = None
    issues: list[Issue] = field(default_factory=list)

    @property
    def errors(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == "warning"]

    @property
    def ok(self) -> bool:
        return self.schema is not None and not self.errors


def error(code: str, location: str, cause: str, hint: str) -> Issue:
    return Issue("error", code, location, cause, hint)


def warning(code: str, location: str, cause: str, hint: str) -> Issue:
    return Issue("warning", code, location, cause, hint)


def format_location(loc: tuple) -> str:
    """('requirements', 1, 'range') -> 'requirements[1].range'"""
    text = ""
    for part in loc:
        if isinstance(part, int):
            text += f"[{part}]"
        else:
            text += f".{part}" if text else str(part)
    return text or "(최상위)"
