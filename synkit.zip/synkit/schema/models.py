"""스키마(YAML)의 구조 정의. 구조·타입·값 범위는 여기서, 항목 간 관계는 checks.py에서 검증한다."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, BeforeValidator, ConfigDict, Field, StringConstraints

# 소문자·숫자·밑줄 단어를 점으로 이은 식별자. 예: electrical.rated_voltage
ID_PATTERN = r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$"

REQUIREMENT_TYPES = ("number", "category", "multi_select", "text")
TEMPLATE_KINDS = ("excel", "docx")
TEMPLATE_LAYOUTS = ("table_rows", "narrative", "matrix_merged_cells")


def _numbers_to_str(value):
    """version: 0.1 처럼 숫자로 적어도 문자열로 받는다."""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return str(value)
    return value


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class UnitConversion(_Strict):
    to: str
    factor: float = Field(gt=0)
    offset: float = 0.0


# 문서에 찍히는 항목 이름. 앞뒤 공백은 지우고, 한 줄이어야 한다. (왕복 파서가 줄 단위로 읽는다)
LabelText = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=1, pattern=r"^[^\r\n]+$")
]


class Labels(_Strict):
    """요구사항 라벨. 한 언어만 써도 되고, 없는 언어는 대체 라벨(schema/labels.py)을 쓴다."""

    ko: LabelText | None = None
    en: LabelText | None = None


class Requirement(_Strict):
    id: Annotated[str, StringConstraints(pattern=ID_PATTERN)]
    type: Literal["number", "category", "multi_select", "text"]
    labels: Labels | None = None
    unit: str | None = None
    # 숫자 유형의 적합성 판정 방향: eq 같아야 함 / min 제품≥요구값 / max 제품≤요구값 (생략하면 eq)
    compare: Literal["eq", "min", "max"] | None = None
    range: Annotated[list[float], Field(min_length=2, max_length=2)] | None = None
    values: Annotated[list[str], Field(min_length=1)] | None = None
    aliases: dict[str, list[str]] | None = None
    unit_aliases: dict[str, list[str]] | None = None
    conversions: dict[str, UnitConversion] | None = None


class ProductDB(_Strict):
    models: int = Field(ge=1)
    variance: float = Field(default=0.0, ge=0.0, le=1.0)


class Template(_Strict):
    name: Annotated[str, StringConstraints(min_length=1)]
    kind: Literal["excel", "docx"]
    layout: Literal["table_rows", "narrative", "matrix_merged_cells"]
    held_out: bool = False


class Variations(_Strict):
    unit_notation_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    language_mix: Annotated[list[Literal["ko", "en"]], Field(min_length=1)] = Field(
        default_factory=lambda: ["ko"]
    )
    typo_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    missing_rate: float = Field(default=0.0, ge=0.0, le=1.0)


class Documents(_Strict):
    count: int = Field(ge=1)
    templates: Annotated[list[Template], Field(min_length=1)]
    variations: Variations = Field(default_factory=Variations)


class GroundTruth(_Strict):
    requirements: Literal["json"] = "json"
    compliance: Literal["auto"] = "auto"
    # 요구값 대비 이 비율 이내로 어긋나면 Partial (docs/decisions.md 15번)
    partial_tolerance: float = Field(default=0.1, ge=0.0, le=1.0)


class Schema(_Strict):
    name: Annotated[str, StringConstraints(min_length=1)]
    version: Annotated[str, BeforeValidator(_numbers_to_str)] = "0.1"
    seed: int = 0
    requirements: Annotated[list[Requirement], Field(min_length=1)]
    product_db: ProductDB
    documents: Documents
    ground_truth: GroundTruth = Field(default_factory=GroundTruth)
