"""▲ 데이터 경계 점검.

스키마에는 비식별 메타정보만 들어가야 한다. 실제 개인·기업 식별자처럼 보이는 문자열이 있으면 경고한다.
경고는 진행을 막지 않는다. (정책 우회가 아니라 실수 방지가 목적이다)

코드: W101 식별자 의심 값
"""

from __future__ import annotations

import re
from typing import Any

from synkit.schema.issues import Issue, warning

# 숫자 앞뒤가 영문자·숫자면 더 긴 토큰(예: sha256 해시)의 일부이므로 식별자로 보지 않는다. 한글·기호 옆은 그대로 본다. (5단계에서 발견)
_RESIDENT_ID = re.compile(r"(?<![0-9A-Za-z])\d{6}-?[1-4]\d{6}(?![0-9A-Za-z])")
_PHONE = re.compile(r"(?<![0-9A-Za-z])0\d{1,2}-\d{3,4}-\d{4}(?![0-9A-Za-z])")
_BUSINESS_NO = re.compile(r"(?<![0-9A-Za-z])\d{3}-\d{2}-\d{5}(?![0-9A-Za-z])")
# 카드번호 모양: 붙여 쓴 13~19자리, 4-4-4-4(-n), 4-6-5. 아무 숫자나 공백·하이픈으로 이은 것은 날짜·시각·run_id와 구분되지 않아
# Luhn을 우연히 통과하는 것(약 10%)을 카드로 오탐하므로, 실제 카드의 묶음 모양일 때만 후보로 본다. (5단계에서 발견)
_CARD_CANDIDATE = re.compile(
    r"(?<![0-9A-Za-z-])(?:\d{4}(?:[ -]\d{4}){2,3}(?:[ -]\d{1,3})?|\d{4}[ -]\d{6}[ -]\d{5}|\d{13,19})(?![0-9A-Za-z-])"
)
_EMAIL = re.compile(r"[\w.+-]+@([\w-]+(?:\.[\w-]+)+)")

_RESERVED_DOMAINS = {"example.com", "example.org", "example.net"}
_RESERVED_SUFFIXES = (".example", ".test", ".invalid", ".localhost")


def _luhn_ok(digits: str) -> bool:
    total = 0
    for index, char in enumerate(reversed(digits)):
        n = int(char)
        if index % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


def _looks_like_card(text: str) -> bool:
    for match in _CARD_CANDIDATE.finditer(text):
        digits = re.sub(r"\D", "", match.group())
        if 13 <= len(digits) <= 19 and _luhn_ok(digits):
            return True
    return False


def _looks_like_real_email(text: str) -> bool:
    for match in _EMAIL.finditer(text):
        domain = match.group(1).lower()
        if domain in _RESERVED_DOMAINS or domain.endswith(_RESERVED_SUFFIXES):
            continue
        return True
    return False


def _kind_of(text: str) -> str | None:
    if _RESIDENT_ID.search(text):
        return "주민등록번호 형식"
    if _looks_like_card(text):
        return "카드번호 형식"
    if _looks_like_real_email(text):
        return "이메일 주소"
    if _PHONE.search(text):
        return "전화번호 형식"
    if _BUSINESS_NO.search(text):
        return "사업자등록번호 형식"
    return None


def _walk(node: Any, path: str):
    """문자열 값을 (위치, 문자열)로 훑는다. 키 이름은 검사하지 않는다."""
    if isinstance(node, str):
        yield path, node
    elif isinstance(node, dict):
        for key, value in node.items():
            yield from _walk(value, f"{path}.{key}" if path else str(key))
    elif isinstance(node, (list, tuple)):
        for index, value in enumerate(node):
            yield from _walk(value, f"{path}[{index}]")


def scan_for_identifiers(data: Any) -> list[Issue]:
    issues: list[Issue] = []
    for location, text in _walk(data, ""):
        kind = _kind_of(text)
        if kind is None:
            continue
        issues.append(
            warning(
                "W101",
                location or "(최상위)",
                f"실제 개인·기업 식별자로 보이는 값({kind})이 있습니다.",
                "스키마에는 실제 값을 넣지 않습니다. 가상 값이나 예약 대역(example.com 등)으로 바꾸세요.",
            )
        )
    return issues


# 점검(check)도 같은 판정을 쓰도록 공개 이름을 둔다. 스키마 경고와 점검이 어긋나지 않게 하기 위해서다.
identifier_kind = _kind_of
walk_strings = _walk
