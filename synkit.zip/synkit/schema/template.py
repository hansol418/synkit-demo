from pathlib import Path

_TEMPLATE_PATH = Path(__file__).with_name("rfq_template.yaml")


def rfq_template_text() -> str:
    """`synkit init`이 만드는 스키마 시작 파일의 내용."""
    return _TEMPLATE_PATH.read_text(encoding="utf-8")
