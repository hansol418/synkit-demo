"""pydantic 오류를 위치·원인·해결 힌트 3요소의 Issue로 바꾼다.

코드 체계: E010 필수 항목 없음, E011 알 수 없는 키, E012 형식 오류,
E013 허용되지 않는 값, E014 항목 개수 오류.
"""

from __future__ import annotations

import difflib

from pydantic import ValidationError

from synkit.schema import models
from synkit.schema.issues import Issue, error, format_location

_TYPE_HINTS = {
    "int_parsing": "정수(예: 30)로 쓰세요.",
    "int_type": "정수(예: 30)로 쓰세요.",
    "float_parsing": "숫자(예: 0.5)로 쓰세요.",
    "float_type": "숫자(예: 0.5)로 쓰세요.",
    "bool_parsing": "true 또는 false로 쓰세요.",
    "bool_type": "true 또는 false로 쓰세요.",
    "string_type": "문자열로 쓰세요. 숫자처럼 보이는 값은 따옴표로 감싸세요.",
    "list_type": "목록으로 쓰세요. 예: [a, b]",
    "dict_type": "키: 값 형태의 묶음으로 쓰세요.",
    "model_attributes_type": "키: 값 형태의 묶음으로 쓰세요.",
}


def _model_for_parent(parent: tuple):
    """오류가 난 키의 부모가 어떤 모델인지 찾는다. (정수 인덱스는 무시)"""
    names = tuple(p for p in parent if not isinstance(p, int))
    if not names:
        return models.Schema
    if len(names) >= 3 and names[-2] == "conversions":
        return models.UnitConversion
    return {
        ("requirements",): models.Requirement,
        ("requirements", "labels"): models.Labels,
        ("product_db",): models.ProductDB,
        ("documents",): models.Documents,
        ("documents", "templates"): models.Template,
        ("documents", "variations"): models.Variations,
        ("ground_truth",): models.GroundTruth,
    }.get(names)


def _unknown_key_hint(loc: tuple) -> str:
    model = _model_for_parent(loc[:-1])
    if model is None:
        return "이 위치에서 허용되는 키를 확인하세요."
    allowed = list(model.model_fields)
    close = difflib.get_close_matches(str(loc[-1]), allowed, n=1)
    if close:
        return f"혹시 `{close[0]}`를 의도하셨나요? 허용되는 키: {', '.join(allowed)}"
    return f"허용되는 키: {', '.join(allowed)}"


def _count_hint(ctx: dict) -> str:
    low, high = ctx.get("min_length"), ctx.get("max_length")
    if low is not None and high is not None and low == high:
        return f"정확히 {low}개를 쓰세요."
    if low is not None:
        return f"최소 {low}개가 필요합니다."
    if high is not None:
        return f"최대 {high}개까지 쓸 수 있습니다."
    return "항목 개수를 확인하세요."


def convert_validation_error(exc: ValidationError) -> list[Issue]:
    issues: list[Issue] = []
    for item in exc.errors():
        loc = tuple(item["loc"])
        location = format_location(loc)
        kind = item["type"]
        ctx = item.get("ctx") or {}
        leaf = loc[-1] if loc else ""

        if kind == "missing":
            issues.append(
                error("E010", location, "필수 항목이 없습니다.", f"`{leaf}` 키를 추가하세요.")
            )
        elif kind == "extra_forbidden":
            issues.append(error("E011", location, "알 수 없는 키입니다.", _unknown_key_hint(loc)))
        elif kind == "literal_error":
            expected = ctx.get("expected", "")
            issues.append(
                error("E013", location, "허용되지 않는 값입니다.", f"허용되는 값: {expected}")
            )
        elif kind == "string_pattern_mismatch":
            if leaf == "id":
                hint = (
                    "id는 소문자·숫자·밑줄로 된 단어를 점(.)으로 이어 쓰세요. "
                    "예: electrical.rated_voltage"
                )
            elif len(loc) >= 2 and loc[-2] == "labels":
                hint = "라벨은 한 줄이어야 합니다. 줄바꿈을 지우세요."
            else:
                hint = "허용되는 형식에 맞게 고치세요."
            issues.append(error("E013", location, "형식이 허용되지 않습니다.", hint))
        elif kind in ("greater_than_equal", "greater_than", "less_than_equal", "less_than"):
            bound = {
                "greater_than_equal": f"{ctx.get('ge')} 이상",
                "greater_than": f"{ctx.get('gt')}보다 큰",
                "less_than_equal": f"{ctx.get('le')} 이하",
                "less_than": f"{ctx.get('lt')}보다 작은",
            }[kind]
            issues.append(
                error("E013", location, "값이 허용 범위를 벗어났습니다.", f"{bound} 값을 쓰세요.")
            )
        elif kind == "string_too_short":
            issues.append(error("E014", location, "비어 있는 문자열입니다.", "한 글자 이상 쓰세요."))
        elif kind in ("too_short", "too_long"):
            issues.append(
                error("E014", location, "항목 개수(또는 길이)가 맞지 않습니다.", _count_hint(ctx))
            )
        else:
            issues.append(
                error(
                    "E012",
                    location,
                    f"값의 형식이 맞지 않습니다. ({item['msg']})",
                    _TYPE_HINTS.get(kind, "값의 형식과 위치를 확인하세요."),
                )
            )
    return issues
