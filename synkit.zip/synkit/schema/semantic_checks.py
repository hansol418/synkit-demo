"""항목 간 관계를 검증한다. 구조·타입은 models.py(pydantic)가 이미 확인했다고 가정한다.

코드 체계: E020 id 중복, E021 범위 순서, E022 숫자 유형 필수 항목 없음,
E023 선택 유형 values 없음, E024 별칭 키 불일치, E025 유형에 맞지 않는 키,
E026 양식 종류와 레이아웃 불일치, E027 단위 환산 대상 불일치, E028 양식 이름 중복.
경고: W102 값 목록 과다, W103 보류 양식 없음.
"""

from __future__ import annotations

from synkit.schema.issues import Issue, error, warning
from synkit.schema.labels import LANGUAGE_NAMES, has_explicit_label, label_for
from synkit.schema.models import Schema

# 유형별로 쓸 수 있는 선택 키
_ALLOWED_KEYS = {
    "number": {"unit", "range", "compare", "unit_aliases", "conversions"},
    "category": {"values", "aliases"},
    "multi_select": {"values", "aliases"},
    "text": set(),
}
_ALL_OPTIONAL_KEYS = {
    "unit", "range", "compare", "values", "aliases", "unit_aliases", "conversions",
}

# 양식 종류별로 가능한 레이아웃
# 렌더러가 있는 조합만 허용한다. (render/registry.py가 같은 목록을 지원한다. 4.7 일관성 테스트가 확인)
_COMPATIBLE_LAYOUTS = {
    "excel": {"table_rows", "matrix_merged_cells"},
    "docx": {"narrative"},
}

LARGE_VALUE_LIST = 30


def check_semantics(schema: Schema) -> list[Issue]:
    issues: list[Issue] = []
    issues += _check_requirements(schema)
    issues += _check_templates(schema)
    issues += _check_notation_candidates(schema)
    issues += _check_duplicate_labels(schema)
    return issues


def _check_duplicate_labels(schema: Schema) -> list[Issue]:
    """같은 언어에서 두 요구사항의 라벨이 같으면 문서에서 구분되지 않는다. (W105)

    대체 라벨(라벨을 안 쓴 경우)도 함께 비교한다. 문서에 쓰이는 언어(language_mix)만 본다.
    """
    issues: list[Issue] = []
    for language in schema.documents.variations.language_mix:
        seen: dict[str, int] = {}
        for index, requirement in enumerate(schema.requirements):
            label = label_for(requirement, language)
            key = " ".join(label.casefold().split())  # 대소문자·공백 차이는 같은 라벨로 본다
            if key not in seen:
                seen[key] = index
                continue
            location = (
                f"requirements[{index}].labels.{language}"
                if has_explicit_label(requirement, language)
                else f"requirements[{index}].id"
            )
            issues.append(
                warning(
                    "W105",
                    location,
                    f"{LANGUAGE_NAMES[language]} 라벨 `{label}`이(가) requirements[{seen[key]}]와 같습니다. "
                    "문서에서 두 항목을 구분할 수 없어 추출·왕복 검증이 모호해집니다.",
                    "두 요구사항 중 하나의 `labels`를 서로 다르게 쓰세요. 라벨을 안 쓴 항목은 id 마지막 단어가 라벨이 됩니다.",
                )
            )
    return issues


def _has_notation_candidates(req) -> bool:
    if req.type == "number":
        spellings = (req.unit_aliases or {}).get(req.unit, [])
        return any(s != req.unit for s in spellings) or bool(req.conversions)
    if req.type in ("category", "multi_select"):
        return any((req.aliases or {}).values())
    return False


def _check_notation_candidates(schema: Schema) -> list[Issue]:
    """표기 변형 비율이 있는데 변형할 표기가 없으면 조용히 무시되므로 경고한다. (W104)"""
    if schema.documents.variations.unit_notation_rate <= 0:
        return []
    if any(_has_notation_candidates(r) for r in schema.requirements):
        return []
    return [
        warning(
            "W104",
            "documents.variations.unit_notation_rate",
            "표기 변형 비율이 0보다 크지만 변형할 표기(단위 별칭, 환산 단위, 값 별칭)가 하나도 없어 적용되지 않습니다.",
            "요구사항에 `unit_aliases`, `conversions`, `aliases`를 정의하거나 `unit_notation_rate`를 0으로 하세요.",
        )
    ]


def _check_requirements(schema: Schema) -> list[Issue]:
    issues: list[Issue] = []
    seen_ids: set[str] = set()

    for i, req in enumerate(schema.requirements):
        base = f"requirements[{i}]"

        if req.id in seen_ids:
            issues.append(
                error(
                    "E020",
                    f"{base}.id",
                    f"id `{req.id}`가 중복되었습니다.",
                    "요구사항 id는 서로 달라야 합니다. 둘 중 하나를 다른 이름으로 바꾸세요.",
                )
            )
        seen_ids.add(req.id)

        # 이 유형에서 쓸 수 없는 키
        allowed = _ALLOWED_KEYS[req.type]
        for key in sorted(_ALL_OPTIONAL_KEYS - allowed):
            if getattr(req, key) is not None:
                issues.append(
                    error(
                        "E025",
                        f"{base}.{key}",
                        f"`{req.type}` 유형에서는 `{key}`를 쓸 수 없습니다.",
                        f"`{key}`를 지우거나 요구사항의 type을 바꾸세요. "
                        f"`{req.type}` 유형에서 쓸 수 있는 키: "
                        f"{', '.join(sorted(allowed)) or '없음'}",
                    )
                )

        if req.type == "number":
            issues += _check_number(req, base)
        elif req.type in ("category", "multi_select"):
            issues += _check_choice(req, base)

    return issues


def _check_number(req, base: str) -> list[Issue]:
    issues: list[Issue] = []

    if req.unit is None:
        issues.append(
            error(
                "E022",
                f"{base}.unit",
                "숫자 유형에는 단위(unit)가 필요합니다.",
                "정규 단위를 적으세요. 예: unit: V",
            )
        )
    if req.range is None:
        issues.append(
            error(
                "E022",
                f"{base}.range",
                "숫자 유형에는 값 범위(range)가 필요합니다.",
                "[최솟값, 최댓값] 형태로 적으세요. 예: range: [9, 16]",
            )
        )
    elif req.range[0] >= req.range[1]:
        issues.append(
            error(
                "E021",
                f"{base}.range",
                f"범위의 시작값({req.range[0]:g})이 끝값({req.range[1]:g})보다 작지 않습니다.",
                f"[{req.range[1]:g}, {req.range[0]:g}]처럼 작은 값을 앞에 쓰세요.",
            )
        )

    conversions = req.conversions or {}
    for source, conv in conversions.items():
        if req.unit is not None and conv.to != req.unit:
            issues.append(
                error(
                    "E027",
                    f"{base}.conversions.{source}.to",
                    f"환산 대상 단위(`{conv.to}`)가 정규 단위(`{req.unit}`)와 다릅니다.",
                    f"`to: {req.unit}`로 바꾸세요. 환산은 항상 정규 단위로 합니다.",
                )
            )
        if req.unit is not None and source == req.unit:
            issues.append(
                error(
                    "E027",
                    f"{base}.conversions.{source}",
                    f"정규 단위(`{req.unit}`) 자신을 환산할 수 없습니다.",
                    "환산이 필요한 다른 단위(예: mA)만 적으세요.",
                )
            )

    if req.unit_aliases:
        valid_units = set(conversions)
        if req.unit is not None:
            valid_units.add(req.unit)
        for unit_key in req.unit_aliases:
            if unit_key not in valid_units:
                issues.append(
                    error(
                        "E024",
                        f"{base}.unit_aliases.{unit_key}",
                        f"별칭 키 `{unit_key}`가 정규 단위나 환산 단위에 없습니다.",
                        f"사용 가능한 키: {', '.join(sorted(valid_units)) or '없음'}",
                    )
                )
    return issues


def _check_choice(req, base: str) -> list[Issue]:
    issues: list[Issue] = []

    if req.values is None:
        issues.append(
            error(
                "E023",
                f"{base}.values",
                f"`{req.type}` 유형에는 허용 값 목록(values)이 필요합니다.",
                "예: values: [EMC, RoHS]",
            )
        )
        return issues

    if req.aliases:
        for key in req.aliases:
            if key not in req.values:
                issues.append(
                    error(
                        "E024",
                        f"{base}.aliases.{key}",
                        f"별칭 키 `{key}`가 values에 없습니다.",
                        f"values에 있는 값만 키로 쓸 수 있습니다: {', '.join(req.values)}",
                    )
                )

    if len(req.values) > LARGE_VALUE_LIST:
        issues.append(
            warning(
                "W102",
                f"{base}.values",
                f"값 목록이 {len(req.values)}개로 깁니다. 실제 목록을 옮겨 적은 것일 수 있습니다.",
                "스키마에는 실제 값이 아닌 대표 값만 쓰세요. 실제 목록이면 가상 값으로 줄이세요.",
            )
        )
    return issues


def _check_templates(schema: Schema) -> list[Issue]:
    issues: list[Issue] = []
    seen_names: set[str] = set()
    templates = schema.documents.templates

    for j, template in enumerate(templates):
        base = f"documents.templates[{j}]"

        if template.name in seen_names:
            issues.append(
                error(
                    "E028",
                    f"{base}.name",
                    f"양식 이름 `{template.name}`이 중복되었습니다.",
                    "양식 이름은 서로 달라야 합니다. 예: format_a, format_b",
                )
            )
        seen_names.add(template.name)

        if template.layout not in _COMPATIBLE_LAYOUTS[template.kind]:
            issues.append(
                error(
                    "E026",
                    f"{base}.layout",
                    f"`{template.kind}` 양식에서는 `{template.layout}` 레이아웃을 쓸 수 없습니다.",
                    f"`{template.kind}`에서 가능한 레이아웃: "
                    f"{', '.join(sorted(_COMPATIBLE_LAYOUTS[template.kind]))}",
                )
            )

    if templates and not any(t.held_out for t in templates):
        issues.append(
            warning(
                "W103",
                "documents.templates",
                "보류 양식(held_out: true)이 없습니다. 개발에 쓴 양식으로만 채점하면 점수가 부풀 수 있습니다.",
                "양식 하나에 `held_out: true`를 붙여 채점 때만 쓰세요.",
            )
        )
    return issues
