"""요구사항 라벨(문서에 찍히는 항목 이름)과 대체 규칙. docs/decisions.md 26번.

스키마 층에 두는 이유: 라벨 중복 경고(W105)가 대체 라벨까지 비교해야 하고, 렌더러·파서·채점이 같은 규칙을 써야 한다.
"""

from __future__ import annotations

from synkit.schema.models import Requirement

LANGUAGES = ("ko", "en")
LANGUAGE_NAMES = {"ko": "한국어", "en": "영어"}


def fallback_label(requirement_id: str) -> str:
    """라벨이 없을 때 쓰는 이름: id의 마지막 단어를 사람이 읽을 형태로. 예: electrical.rated_voltage → Rated voltage"""
    words = requirement_id.split(".")[-1].replace("_", " ").strip()
    return words[:1].upper() + words[1:]


def _explicit(requirement: Requirement, language: str) -> str | None:
    return getattr(requirement.labels, language) if requirement.labels else None


def has_explicit_label(requirement: Requirement, language: str) -> bool:
    return _explicit(requirement, language) is not None


def label_for(requirement: Requirement, language: str) -> str:
    """해당 언어의 라벨. 스키마에 없으면 대체 라벨을 돌려준다."""
    if language not in LANGUAGES:
        raise ValueError(f"지원하지 않는 언어입니다: {language!r} (지원: {', '.join(LANGUAGES)})")
    return _explicit(requirement, language) or fallback_label(requirement.id)
