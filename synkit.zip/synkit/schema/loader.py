"""스키마 파일을 읽고 검증하는 진입점.

순서: YAML 파싱(E001/E002) → 구조·타입(pydantic, E010~E014) → 항목 간 관계(E020~E028)
      → 데이터 경계 경고(W101~W103).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import ValidationError

from synkit.schema.boundary import scan_for_identifiers
from synkit.schema.issues import LoadResult, error
from synkit.schema.models import Schema
from synkit.schema.semantic_checks import check_semantics
from synkit.schema.structure_errors import convert_validation_error


def validate_data(data: Any) -> LoadResult:
    """이미 파싱된 데이터를 검증한다."""
    if not isinstance(data, dict):
        return LoadResult(
            issues=[
                error(
                    "E012",
                    "(최상위)",
                    "스키마의 최상위는 `키: 값` 형태의 묶음이어야 합니다.",
                    "파일이 비었거나 목록으로 시작하는지 확인하세요. `synkit init`으로 시작 파일을 만들 수 있습니다.",
                )
            ]
        )

    result = LoadResult()
    try:
        result.schema = Schema.model_validate(data)
    except ValidationError as exc:
        result.issues += convert_validation_error(exc)

    if result.schema is not None:
        result.issues += check_semantics(result.schema)

    result.issues += scan_for_identifiers(data)
    return result


def load_schema_file(path: str | Path) -> LoadResult:
    """YAML 파일을 읽어 검증한다."""
    path = Path(path)

    if not path.exists():
        return LoadResult(
            issues=[
                error(
                    "E002",
                    str(path),
                    "파일을 찾을 수 없습니다.",
                    "경로를 확인하세요. 시작 파일이 필요하면 `synkit init`을 실행하세요.",
                )
            ]
        )

    try:
        text = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        return LoadResult(
            issues=[
                error(
                    "E001",
                    str(path),
                    "UTF-8로 읽을 수 없습니다.",
                    "파일을 UTF-8 인코딩으로 다시 저장하세요.",
                )
            ]
        )

    try:
        data = yaml.safe_load(text)
    except yaml.MarkedYAMLError as exc:
        line = exc.problem_mark.line + 1 if exc.problem_mark else "?"
        return LoadResult(
            issues=[
                error(
                    "E001",
                    f"줄 {line}",
                    f"YAML 문법 오류입니다. ({exc.problem})",
                    "해당 줄 근처의 괄호 짝, 들여쓰기(공백), 콜론 뒤 공백을 확인하세요.",
                )
            ]
        )
    except yaml.YAMLError as exc:
        return LoadResult(
            issues=[
                error("E001", str(path), f"YAML을 읽을 수 없습니다. ({exc})", "YAML 문법을 확인하세요.")
            ]
        )

    return validate_data(data)
