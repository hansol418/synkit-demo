"""실행 폴더(runs/<run_id>/)를 읽는 단일 경로. (devplan 2-2, 단계 4.1)

`render`, `check`, `grade`, `report`는 실행 폴더를 이 모듈로만 읽는다. 저장소가 바뀌어도(예: 데이터베이스)
이 이음새만 바꾸면 되도록 하기 위해서다.

읽기 순서와 오류 코드
  E200 폴더 없음 · E201 파일 없음 · E202 JSON/CSV 읽기 실패 · E203 해시 불일치
  E204 계약 버전 없음·미지원 · E205 스키마 사본 무효 · E206 파일 간 불일치 · E207 JSON 버전 미지원
읽기 전용이다. 폴더를 수정하지 않는다.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from synkit.constants import CONTRACT_VERSION
from synkit.generate.models import (
    ComplianceResult,
    Dataset,
    DisplayItem,
    Document,
    ProductModel,
    RequirementValue,
)
from synkit.generate.writer import DATA_FILES
from synkit.schema.issues import Issue, error
from synkit.schema.loader import load_schema_file
from synkit.schema.models import Requirement, Schema

SUPPORTED_CONTRACT_VERSIONS = (CONTRACT_VERSION,)
SUPPORTED_JSON_VERSIONS = ("1",)

_REGENERATE_HINT = "실행 폴더의 파일을 직접 고치지 말고, 같은 스키마로 `synkit generate`를 다시 실행해 새 실행을 만드세요."


class RunError(Exception):
    """실행 폴더를 읽을 수 없을 때. 위치·원인·힌트를 가진 Issue 목록을 담는다."""

    def __init__(self, issues: list[Issue]):
        self.issues = list(issues)
        super().__init__("\n".join(
            f"[오류 {i.code}] {i.location}: {i.cause} (힌트: {i.hint})" for i in self.issues
        ))


@dataclass(frozen=True)
class RunData:
    path: Path
    run_id: str
    meta: dict[str, Any]
    generated_at: datetime  # 시간대 포함
    schema: Schema
    schema_text: str
    dataset: Dataset

    @property
    def documents_dir(self) -> Path:
        return self.path / "documents"


# ---------------------------------------------------------------- 읽기 도우미

def _read_json(run_path: Path, name: str, issues: list[Issue]) -> Any | None:
    path = run_path / name
    if not path.is_file():
        issues.append(error(
            "E201", name, "필수 파일이 없습니다.",
            f"{_REGENERATE_HINT} (누락된 파일: {name})",
        ))
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        issues.append(error(
            "E202", name, f"JSON을 읽을 수 없습니다. ({exc})", _REGENERATE_HINT,
        ))
        return None


def _check_contract(meta: dict, issues: list[Issue]) -> None:
    version = meta.get("contract_version")
    supported = ", ".join(str(v) for v in SUPPORTED_CONTRACT_VERSIONS)
    if version is None:
        issues.append(error(
            "E204", "run_meta.json", "계약 버전(contract_version)이 없습니다. 이전 형식의 실행일 수 있습니다.",
            f"이 synkit이 읽는 계약 버전은 {supported}입니다. 새 synkit으로 `synkit generate`를 다시 실행하세요.",
        ))
    elif version not in SUPPORTED_CONTRACT_VERSIONS:
        issues.append(error(
            "E204", "run_meta.json", f"지원하지 않는 계약 버전입니다. (실행의 버전: {version})",
            f"이 synkit이 읽을 수 있는 계약 버전은 {supported}입니다. 같은 버전의 synkit을 쓰거나 `synkit generate`를 다시 실행하세요.",
        ))


def _check_files(run_path: Path, meta: dict, verify: bool, issues: list[Issue]) -> None:
    files = meta.get("files")
    if not isinstance(files, dict):
        issues.append(error(
            "E206", "run_meta.json", "파일 해시 목록(files)이 없거나 형식이 다릅니다.", _REGENERATE_HINT,
        ))
        return

    for name in DATA_FILES:
        path = run_path / name
        if not path.is_file():
            issues.append(error("E201", name, "필수 파일이 없습니다.", f"{_REGENERATE_HINT} (누락된 파일: {name})"))
        elif name not in files:
            issues.append(error(
                "E206", "run_meta.json", f"`{name}`의 해시가 run_meta.json에 없습니다.", _REGENERATE_HINT,
            ))
        elif verify and hashlib.sha256(path.read_bytes()).hexdigest() != files[name]:
            issues.append(error(
                "E203", name, "파일 내용이 생성 당시와 다릅니다. (sha256 불일치)", _REGENERATE_HINT,
            ))


def _parse_cell(spec: Requirement, text: str) -> Any:
    if spec.type == "number":
        return int(text) if re.fullmatch(r"-?\d+", text) else float(text)
    if spec.type == "multi_select":
        return text.split("|") if text else []
    return text


def _read_product_db(run_path: Path, schema: Schema, issues: list[Issue]) -> tuple[ProductModel, ...] | None:
    spec = {r.id: r for r in schema.requirements}
    try:
        with open(run_path / "product_db.csv", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            expected = ["model_id"] + [r.id for r in schema.requirements]
            if reader.fieldnames != expected:
                issues.append(error(
                    "E206", "product_db.csv", "열 구성이 스키마 사본과 다릅니다.", _REGENERATE_HINT,
                ))
                return None
            return tuple(
                ProductModel(row["model_id"], {i: _parse_cell(spec[i], row[i]) for i in spec})
                for row in reader
            )
    except (ValueError, KeyError) as exc:
        issues.append(error("E202", "product_db.csv", f"값을 읽을 수 없습니다. ({exc})", _REGENERATE_HINT))
        return None


def _check_json_version(name: str, content: Any, issues: list[Issue]) -> bool:
    version = content.get("schema_version") if isinstance(content, dict) else None
    if version in SUPPORTED_JSON_VERSIONS:
        return True
    issues.append(error(
        "E207", name, f"지원하지 않는 형식 버전입니다. (schema_version: {version!r})",
        f"이 synkit이 읽을 수 있는 버전은 {', '.join(SUPPORTED_JSON_VERSIONS)}입니다. {_REGENERATE_HINT}",
    ))
    return False


def _build_documents(truth: dict, plan: dict, schema: Schema, issues: list[Issue]) -> tuple[Document, ...] | None:
    expected_ids = [r.id for r in schema.requirements]
    try:
        truth_docs = list(truth["documents"])
        plan_by_id = {d["doc_id"]: d for d in plan["documents"]}
        truth_ids = {d["doc_id"] for d in truth_docs}
        if truth_ids != set(plan_by_id):
            issues.append(error(
                "E206", "document_plan.json", "문서 목록이 ground_truth.json과 다릅니다.", _REGENERATE_HINT,
            ))
            return None

        documents = []
        for doc in truth_docs:
            plan_doc = plan_by_id[doc["doc_id"]]
            truth_ids_in_doc = [r["id"] for r in doc["requirements"]]
            plan_ids_in_doc = [i["id"] for i in plan_doc["items"]]
            if truth_ids_in_doc != expected_ids or plan_ids_in_doc != expected_ids:
                issues.append(error(
                    "E206", "document_plan.json",
                    f"문서 {doc['doc_id']}의 항목 구성이 스키마 사본이나 ground_truth.json과 다릅니다.",
                    _REGENERATE_HINT,
                ))
                return None
            if plan_doc["template"] != doc["template"]:
                issues.append(error(
                    "E206", "document_plan.json",
                    f"문서 {doc['doc_id']}의 양식이 ground_truth.json과 다릅니다.", _REGENERATE_HINT,
                ))
                return None
            documents.append(Document(
                doc["doc_id"], doc["template"], doc["target_model"],
                tuple(RequirementValue(r["id"], r["value"], r.get("unit")) for r in doc["requirements"]),
                tuple(ComplianceResult(c["id"], c["status"]) for c in doc["compliance"]),
                plan_doc["language"],
                tuple(
                    DisplayItem(
                        i["id"], i["present"], i["shown_value"], i["shown_unit"],
                        i["converted_from"], tuple(i["variations"]),
                    )
                    for i in plan_doc["items"]
                ),
            ))
        return tuple(documents)
    except (KeyError, TypeError) as exc:
        issues.append(error(
            "E202", "ground_truth.json / document_plan.json",
            f"JSON의 구조가 기대와 다릅니다. (누락된 키: {exc})", _REGENERATE_HINT,
        ))
        return None


def _parse_generated_at(meta: dict, issues: list[Issue]) -> datetime | None:
    try:
        value = datetime.fromisoformat(meta["generated_at"])
    except (KeyError, TypeError, ValueError):
        issues.append(error(
            "E206", "run_meta.json", "생성 시각(generated_at)을 읽을 수 없습니다.", _REGENERATE_HINT,
        ))
        return None
    if value.tzinfo is None:
        issues.append(error(
            "E206", "run_meta.json", "생성 시각에 시간대가 없습니다.", _REGENERATE_HINT,
        ))
        return None
    return value


def _check_counts(meta: dict, schema: Schema, dataset: Dataset, issues: list[Issue]) -> None:
    expected = {
        "documents": len(dataset.documents),
        "models": len(dataset.models),
        "requirements": len(schema.requirements),
    }
    counts = meta.get("counts")
    if not isinstance(counts, dict) or any(counts.get(k) != v for k, v in expected.items()):
        issues.append(error(
            "E206", "run_meta.json",
            f"개수(counts)가 실제 데이터와 다릅니다. (실제: {expected}, 기록: {counts})", _REGENERATE_HINT,
        ))


# ---------------------------------------------------------------- 진입점

def load_run(path: str | Path, *, verify: bool = True) -> RunData:
    """실행 폴더를 읽어 RunData로 돌려준다. 읽을 수 없으면 RunError.

    verify=True(기본)이면 run_meta.json의 sha256과 실제 파일을 대조한다.
    """
    run_path = Path(path)
    if not run_path.is_dir():
        raise RunError([error(
            "E200", str(run_path), "실행 폴더를 찾을 수 없거나 폴더가 아닙니다.",
            "`synkit generate`가 만든 runs/<run_id> 폴더 경로를 지정하세요.",
        )])

    issues: list[Issue] = []

    meta = _read_json(run_path, "run_meta.json", issues)
    if issues:
        raise RunError(issues)
    if not isinstance(meta, dict):
        raise RunError([error("E202", "run_meta.json", "JSON의 최상위가 객체가 아닙니다.", _REGENERATE_HINT)])

    _check_contract(meta, issues)
    if issues:
        raise RunError(issues)

    _check_files(run_path, meta, verify, issues)
    if issues:
        raise RunError(issues)

    schema_path = run_path / "schema.yaml"
    result = load_schema_file(schema_path)
    if not result.ok:
        first = result.errors[0]
        raise RunError([error(
            "E205", "schema.yaml",
            f"스키마 사본이 유효하지 않습니다. ({first.code} {first.location}: {first.cause})",
            "원본 스키마를 `synkit validate`로 확인하고, " + _REGENERATE_HINT,
        )])
    schema = result.schema

    truth = _read_json(run_path, "ground_truth.json", issues)
    plan = _read_json(run_path, "document_plan.json", issues)
    if issues:
        raise RunError(issues)
    ok_truth = _check_json_version("ground_truth.json", truth, issues)
    ok_plan = _check_json_version("document_plan.json", plan, issues)
    if not (ok_truth and ok_plan):
        raise RunError(issues)

    models = _read_product_db(run_path, schema, issues)
    documents = _build_documents(truth, plan, schema, issues)
    generated_at = _parse_generated_at(meta, issues)
    if issues:
        raise RunError(issues)

    dataset = Dataset(meta["seed"], meta["schema_name"], meta["schema_version"], models, documents)
    _check_counts(meta, schema, dataset, issues)
    if issues:
        raise RunError(issues)

    return RunData(
        path=run_path,
        run_id=meta["run_id"],
        meta=meta,
        generated_at=generated_at,
        schema=schema,
        schema_text=schema_path.read_text(encoding="utf-8"),
        dataset=dataset,
    )
