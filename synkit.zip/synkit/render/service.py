"""실행 폴더의 문서를 렌더하고 왕복 검증한 뒤 documents/에 원자적으로 기록한다. (devplan 4.8, 결정 29·41)

흐름: 실행 폴더 읽기(호출자, run_io.load_run) → 임시 폴더에 문서 렌더 → 파일을 다시 읽어 왕복 검증 →
manifest.json 작성 → 임시 폴더를 documents/로 교체. 중간에 실패하면 documents/는 이전 상태 그대로이고
임시 폴더는 남지 않는다. 실행 폴더의 다른 파일(run_meta.json 포함)은 수정하지 않는다.

manifest.json에는 시각과 이 PC의 경로를 넣지 않는다. (같은 입력이면 같은 manifest)
오류 코드: E310 documents/ 폴더가 이미 있음 · E311 --only의 양식 이름을 알 수 없음
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Sequence

from synkit.constants import LIMITATION_NOTICE
from synkit.render.model import build_view
from synkit.render.registry import document_filename, render_document, roundtrip_document
from synkit.render.roundtrip import Mismatch
from synkit.run_io import RunData
from synkit.schema.issues import Issue, error

MANIFEST_NAME = "manifest.json"
MANIFEST_VERSION = "1"
_DOCUMENTS = "documents"
_TEMP = "documents.tmp"
_OLD = "documents.old"


class RenderError(Exception):
    """렌더를 시작할 수 없을 때. 위치·원인·힌트를 가진 Issue 목록을 담는다."""

    def __init__(self, issues: list[Issue]):
        self.issues = list(issues)
        super().__init__("\n".join(
            f"[오류 {i.code}] {i.location}: {i.cause} (힌트: {i.hint})" for i in self.issues
        ))


@dataclass(frozen=True)
class RenderSummary:
    directory: Path
    manifest_path: Path
    documents: int
    by_template: dict[str, int]
    l1_mismatches: int
    l2_mismatches: int
    l2_checked: int
    typo_skipped: int
    problems: tuple[Mismatch, ...] = field(default=())

    @property
    def ok(self) -> bool:
        return not self.problems


def _content_hash(parsed) -> str:
    """문서가 말하는 내용(파싱한 항목)의 해시. 파일 바이트 해시와 달리 포장 방식에 영향받지 않는다."""
    text = json.dumps(dataclasses.asdict(parsed), ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _json_bytes(data) -> bytes:
    return (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _select_templates(run: RunData, only: Sequence[str] | None):
    templates = list(run.schema.documents.templates)
    if only is None:
        return templates
    names = [t.name for t in templates]
    unknown = [name for name in only if name not in names]
    if unknown:
        raise RenderError([error(
            "E311", f"--only {', '.join(unknown)}",
            f"스키마에 없는 양식 이름입니다. ({', '.join(unknown)})",
            f"스키마의 양식 이름 중에서 고르세요: {', '.join(names)}",
        )])
    return [t for t in templates if t.name in set(only)]


def _discard(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path, ignore_errors=True)


def render_run(run: RunData, *, only: Sequence[str] | None = None, force: bool = False) -> RenderSummary:
    target = run.path / _DOCUMENTS
    temp, old = run.path / _TEMP, run.path / _OLD

    selected = _select_templates(run, only)
    if target.exists() and not force:
        raise RenderError([error(
            "E310", str(target), "문서 폴더가 이미 있어 덮어쓰지 않았습니다.",
            "기존 문서를 지우고 다시 만들려면 `--force`를 붙이세요. 실행 폴더의 데이터는 바뀌지 않습니다.",
        )])

    by_name = {t.name: t for t in selected}
    _discard(temp)  # 이전 실행이 중단되며 남은 임시 폴더
    _discard(old)
    temp.mkdir()
    try:
        entries = []
        counts = {name: 0 for name in by_name}
        problems: list[Mismatch] = []
        l1_total = l2_total = checked = skipped = 0

        for document in run.dataset.documents:
            template = by_name.get(document.template)
            if template is None:
                continue
            path = render_document(build_view(run.schema, document), template, temp)
            result = roundtrip_document(path, run.schema, template, document)

            l1, l2 = len(result.l1), len(result.l2.mismatches)
            l1_total, l2_total = l1_total + l1, l2_total + l2
            checked += result.l2.checked
            skipped += result.l2.typo_skipped
            problems.extend(result.l1)
            problems.extend(result.l2.mismatches)
            counts[template.name] += 1
            entries.append({
                "doc_id": document.doc_id,
                "template": document.template,
                "language": document.language,
                "file": document_filename(document.doc_id, template),
                "size": path.stat().st_size,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "content_sha256": _content_hash(result.parsed),
                "roundtrip": {
                    "l1": l1, "l2": l2, "l2_checked": result.l2.checked, "typo_skipped": result.l2.typo_skipped,
                },
            })

        manifest = {
            "schema_version": MANIFEST_VERSION,
            "run_id": run.run_id,
            "contract_version": run.meta["contract_version"],
            "only": list(only) if only is not None else None,
            "notice": LIMITATION_NOTICE,
            "templates": [{"name": name, "documents": n} for name, n in counts.items()],
            "documents": entries,
        }
        (temp / MANIFEST_NAME).write_bytes(_json_bytes(manifest))

        if target.exists():
            target.rename(old)
            try:
                temp.rename(target)
            except BaseException:
                old.rename(target)
                raise
            _discard(old)
        else:
            temp.rename(target)
    except BaseException:
        _discard(temp)
        raise

    return RenderSummary(
        directory=target,
        manifest_path=target / MANIFEST_NAME,
        documents=len(entries),
        by_template=counts,
        l1_mismatches=l1_total,
        l2_mismatches=l2_total,
        l2_checked=checked,
        typo_skipped=skipped,
        problems=tuple(problems),
    )
