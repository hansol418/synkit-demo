"""엑셀 양식(A, C)이 공통으로 쓰는 도우미."""

from __future__ import annotations

from openpyxl import Workbook

from synkit.render.model import FIXED_TIMESTAMP, DocumentView


def set_text(cell, text: str) -> None:
    """문자열을 문자열 셀로 쓴다. '='로 시작해도 수식으로 해석되지 않게 한다."""
    cell.value = text
    cell.data_type = "s"


def display_width(text: str) -> int:
    """엑셀 열 너비 추정: 한글 같은 넓은 글자는 2칸."""
    return sum(2 if ord(ch) > 127 else 1 for ch in str(text))


def max_display_width(texts: list[str]) -> int:
    return max(display_width(t) for t in texts)


def apply_properties(workbook: Workbook, view: DocumentView) -> None:
    """파일 속성에 합성 문서임을 기록하고 시각을 고정값으로 둔다.

    주의: openpyxl은 **저장할 때** modified를 현재 시각으로 덮어쓴다. 저장된 파일의 시각은
    저장 직후 `ooxml.normalize_package`가 고정한다. (결정 35, 41)
    """
    props = workbook.properties
    props.creator = view.properties["creator"]
    props.lastModifiedBy = view.properties["creator"]
    props.title = view.properties["title"]
    props.subject = view.properties["subject"]
    props.keywords = view.properties["keywords"]
    props.created = FIXED_TIMESTAMP
    props.modified = FIXED_TIMESTAMP
