"""양식 B (docx / narrative): 항목마다 한 문장. (devplan 4.5)

문장 틀을 이 모듈 한 곳에서 정의하고, 렌더러(format_item_sentence)와 왕복 파서(parse_item_sentence)가 같은 정의를 쓴다.
같은 가정을 공유하는 위험은 문장 틀을 손으로 쓴 정답과 대조하는 테스트로 막는다.

라벨은 **전체 일치**로 찾는다. 라벨 바로 뒤에 구분자(조사 / ` shall be ` / `: `)가 와야 하므로
한 라벨이 다른 라벨의 앞부분이어도 서로 헷갈리지 않는다. (결정 33)

문장 틀
  ko 숫자  {라벨}{은|는|은(는)} {값 단위} {이어야 | 이상이어야 | 이하여야} 한다.
  en 숫자  {라벨} shall be [at least | at most] {값 단위}.
  그 밖의 값(두 언어 공통)  {라벨}: {값}.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from docx import Document
from docx.oxml.ns import qn

from synkit.render.model import FIXED_TIMESTAMP, DocumentView, ViewItem
from synkit.render.ooxml import normalize_package

FONT_NAME = "Malgun Gothic"
LEADING_PARAGRAPHS = 3  # 제목, 합성 표시, 서론
INTRO = {
    "ko": "본 문서는 다음 사양을 요구한다.",
    "en": "This document specifies the following requirements.",
}

_KO_TAIL = {"eq": "이어야 한다.", "min": "이상이어야 한다.", "max": "이하여야 한다."}
_EN_PREFIX = {"eq": "", "min": "at least ", "max": "at most "}

_KO_PARTICLE = re.compile(r"^(?:은\(는\)|은|는) (?P<body>.*)$")
_KO_NUMBER = re.compile(
    r"^(?P<value>-?\d+(?:\.\d+)?) (?P<unit>.+?) (?P<tail>이상이어야|이하여야|이어야) 한다\.$"
)
_KO_DIRECTION = {"이상이어야": "min", "이하여야": "max", "이어야": "eq"}
_EN_NUMBER = re.compile(
    r"^ shall be (?:(?P<direction>at least|at most) )?(?P<value>-?\d+(?:\.\d+)?) (?P<unit>.+)\.$"
)
_EN_DIRECTION = {"at least": "min", "at most": "max", None: "eq"}


@dataclass(frozen=True)
class ParsedSentence:
    label: str
    value_text: str
    unit_text: str | None  # 숫자 문장만
    direction: str | None  # 숫자 문장만: eq / min / max


def topic_particle(label: str) -> str:
    """한국어 주제 조사. 마지막 글자가 한글이면 받침에 따라 은/는, 아니면 은(는)."""
    last = label.rstrip()[-1:]
    if "가" <= last <= "힣":
        return "은" if (ord(last) - 0xAC00) % 28 else "는"
    return "은(는)"


def format_item_sentence(item: ViewItem, language: str) -> str:
    if language not in ("ko", "en"):
        raise ValueError(f"지원하지 않는 언어입니다: {language!r}")
    if item.kind != "number":
        return f"{item.label}: {item.value_text}."
    if language == "ko":
        return f"{item.label}{topic_particle(item.label)} {item.value_with_unit} {_KO_TAIL[item.compare]}"
    return f"{item.label} shall be {_EN_PREFIX[item.compare]}{item.value_with_unit}."


def parse_item_sentence(sentence: str, labels: Sequence[str], language: str) -> ParsedSentence | None:
    """format_item_sentence의 역. 문장에서 라벨·값·단위·방향을 읽는다. 읽을 수 없으면 None."""
    if language not in ("ko", "en"):
        raise ValueError(f"지원하지 않는 언어입니다: {language!r}")

    for label in sorted(labels, key=len, reverse=True):  # 긴 라벨부터. 구분자까지 맞아야 한다
        if not sentence.startswith(label):
            continue
        rest = sentence[len(label):]

        if rest.startswith(": ") and rest.endswith("."):
            return ParsedSentence(label, rest[2:-1], None, None)

        if language == "ko":
            particle = _KO_PARTICLE.match(rest)
            number = _KO_NUMBER.match(particle.group("body")) if particle else None
            if number:
                return ParsedSentence(
                    label, number.group("value"), number.group("unit"), _KO_DIRECTION[number.group("tail")]
                )
        else:
            number = _EN_NUMBER.match(rest)
            if number:
                return ParsedSentence(
                    label, number.group("value"), number.group("unit"), _EN_DIRECTION[number.group("direction")]
                )
    return None


def _set_fonts(document) -> None:
    """East Asian 글꼴까지 지정해야 워드가 한글을 어색한 글꼴로 보여 주지 않는다."""
    normal = document.styles["Normal"]
    normal.font.name = FONT_NAME
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), FONT_NAME)


def build_document(view: DocumentView):
    document = Document()
    _set_fonts(document)

    document.add_heading(view.title, 0)  # "Title" 스타일
    document.add_paragraph(view.synthetic_mark)
    document.add_paragraph(INTRO[view.language])
    for item in view.items:
        document.add_paragraph(format_item_sentence(item, view.language))

    props = document.core_properties
    props.author = view.properties["creator"]
    props.last_modified_by = view.properties["creator"]
    props.title = view.properties["title"]
    props.subject = view.properties["subject"]
    props.keywords = view.properties["keywords"]
    props.created = FIXED_TIMESTAMP
    props.modified = FIXED_TIMESTAMP
    return document


def write_docx_b(view: DocumentView, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    build_document(view).save(str(path))
    return normalize_package(path)
