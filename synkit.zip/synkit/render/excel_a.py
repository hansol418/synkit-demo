"""양식 A (excel / table_rows): 한 시트의 표. 값과 단위가 별도 셀이다. (devplan 4.4)

레이아웃 (왕복 파서가 같은 상수를 쓴다)
  1행  제목 · 2행  합성 표시 · 3행  비움 · 4행  표 머리(번호/항목/요구값/단위) · 5행부터 항목
숫자는 숫자 셀로, 그 밖의 값은 문자열 셀로 쓴다. 누락된 항목은 행이 없다.
"""

from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

from synkit.render.excel_common import apply_properties, max_display_width, set_text
from synkit.render.model import DocumentView
from synkit.render.ooxml import normalize_package

SHEET_NAME = "RFQ"
TABLE_HEADER_ROW = 4
FIRST_ITEM_ROW = 5
HEADERS = {
    "ko": ("번호", "항목", "요구값", "단위"),
    "en": ("No.", "Item", "Requirement", "Unit"),
}

_HEADER_FILL = PatternFill("solid", fgColor="E7E6E6")


def _number(value: int | float) -> int | float:
    """정수값 소수(12.0)는 정수로 쓴다. 그 밖의 소수는 그대로 둬 값이 변하지 않는다."""
    return int(value) if float(value).is_integer() else value


def build_workbook(view: DocumentView) -> Workbook:
    wb = Workbook()
    ws = wb.active
    ws.title = SHEET_NAME

    set_text(ws["A1"], view.title)
    ws["A1"].font = Font(bold=True, size=14)
    set_text(ws["A2"], view.synthetic_mark)

    for column, header in enumerate(HEADERS[view.language], start=1):
        cell = ws.cell(TABLE_HEADER_ROW, column)
        set_text(cell, header)
        cell.font = Font(bold=True)
        cell.fill = _HEADER_FILL

    for number, item in enumerate(view.items, start=1):
        row = FIRST_ITEM_ROW + number - 1
        ws.cell(row, 1, number)
        set_text(ws.cell(row, 2), item.label)
        if item.kind == "number":
            ws.cell(row, 3, _number(item.shown_value))
            if item.unit_text:
                set_text(ws.cell(row, 4), item.unit_text)
        else:
            set_text(ws.cell(row, 3), item.value_text)
        ws.cell(row, 3).alignment = Alignment(wrap_text=True, vertical="top")

    labels = [HEADERS[view.language][1]] + [i.label for i in view.items]
    values = [HEADERS[view.language][2]] + [i.value_text for i in view.items]
    units = [HEADERS[view.language][3]] + [i.unit_text or "" for i in view.items]
    ws.column_dimensions["A"].width = 8
    ws.column_dimensions["B"].width = max(12, max_display_width(labels) + 2)
    ws.column_dimensions["C"].width = min(60, max(16, max_display_width(values) + 2))
    ws.column_dimensions["D"].width = max(10, max_display_width(units) + 2)

    apply_properties(wb, view)
    return wb


def write_excel_a(view: DocumentView, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    build_workbook(view).save(path)
    return normalize_package(path)
