"""오라클 파서와 왕복 검증. (devplan 4.7, KR1-c)

렌더러가 만든 **파일을 라이브러리(openpyxl, python-docx)로 직접 읽어** 항목을 복원하고 두 층으로 대조한다.
- L1 (문서 ↔ 표시 계획): 읽은 값이 document_plan과 정확히 같은가. 오타가 든 문자열도 그대로 같아야 한다.
- L2 (표시 ↔ 정답): 오타가 없는 항목은 normalize_shown으로 정규화한 값이 정답과 같은가.
  오타 항목은 정규화에 **실패해야** 한다. (오타가 알려진 표기와 같아지면 안 된다는 생성 불변식)

이 파서는 **렌더러의 정합성을 확인하는 도구**다. 사용자의 추출 로직이 아니며, 데모 추출기(8단계)는 이 모듈을
import하지 않는다. (순환 평가 방지) 양식 B의 파서는 렌더러와 같은 문장 틀 정의를 쓰므로(docx_b),
그 정의 자체는 손으로 쓴 정답 문장과 대조하는 테스트로 따로 시험한다.

오류 코드: E300 파일을 읽을 수 없음 · E301 기대한 시트가 없음 · E302 언어를 알아낼 수 없음
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import docx
import openpyxl

from synkit.constants import SYNTHETIC_TOKEN
from synkit.generate.models import Document
from synkit.generate.normalize import UnknownNotation, normalize_shown
from synkit.render import excel_a, excel_c
from synkit.render.docx_b import INTRO, LEADING_PARAGRAPHS, parse_item_sentence
from synkit.render.model import TITLES, group_title
from synkit.schema.issues import Issue, error
from synkit.schema.labels import label_for
from synkit.schema.models import Requirement, Schema

_READ_HINT = "렌더러가 만든 파일인지, 편집으로 구조가 바뀌지 않았는지 확인하고 `synkit render`를 다시 실행하세요."


class ParseError(Exception):
    """문서를 읽을 수 없을 때. 위치·원인·힌트를 가진 Issue를 담는다."""

    def __init__(self, issue: Issue):
        self.issue = issue
        super().__init__(f"[오류 {issue.code}] {issue.location}: {issue.cause} (힌트: {issue.hint})")


@dataclass(frozen=True)
class ParsedItem:
    id: str
    label: str
    value: Any  # 숫자 요구사항은 숫자, 다중 선택은 목록, 그 밖은 문자열. 읽은 그대로(타입이 틀려도 보존)
    unit: str | None
    group: str | None = None  # 양식 C: 병합 셀 값을 전파해 얻은 그룹 이름
    direction: str | None = None  # 양식 B: eq / min / max
    remarks: str | None = None  # 양식 C: 비고 열 (렌더러는 항상 비운다)


@dataclass(frozen=True)
class ParsedDocument:
    doc_id: str | None
    language: str
    title: str | None
    synthetic_mark: str | None
    items: tuple[ParsedItem, ...]
    unparsed: tuple[str, ...]  # 읽을 수 없었던 행·문장
    has_groups: bool = False
    has_directions: bool = False

    @property
    def has_synthetic_mark(self) -> bool:
        return bool(self.synthetic_mark and self.synthetic_mark.startswith(SYNTHETIC_TOKEN))


@dataclass(frozen=True)
class Mismatch:
    doc_id: str
    requirement_id: str | None
    field: str  # doc_id, language, unparsed, presence, order, duplicate, value, unit, group, direction, remarks, ...
    expected: Any
    actual: Any


@dataclass(frozen=True)
class NormalizationResult:
    checked: int
    typo_skipped: int
    mismatches: tuple[Mismatch, ...]


@dataclass(frozen=True)
class RoundtripResult:
    parsed: ParsedDocument
    l1: tuple[Mismatch, ...]
    l2: NormalizationResult

    @property
    def ok(self) -> bool:
        return not self.l1 and not self.l2.mismatches


# ---------------------------------------------------------------- 읽기 도우미

def _fail(code: str, location: str, cause: str, hint: str = _READ_HINT):
    raise ParseError(error(code, location, cause, hint))


def _to_number(text: str) -> int | float:
    return int(text) if re.fullmatch(r"-?\d+", text) else float(text)


def _label_index(schema: Schema, language: str) -> dict[str, Requirement]:
    return {label_for(r, language): r for r in schema.requirements}


def _doc_id_from_title(title: str | None, language: str) -> str | None:
    match = re.fullmatch(rf"{re.escape(TITLES[language])} (\S+)", title or "")
    return match.group(1) if match else None


def _open_sheet(path: str | Path, sheet_name: str):
    path = Path(path)
    try:
        workbook = openpyxl.load_workbook(path)
    except Exception as exc:  # 없는 파일, 손상된 파일, 형식이 다른 파일
        _fail("E300", path.name, f"파일을 읽을 수 없습니다. ({type(exc).__name__})")
    if sheet_name not in workbook.sheetnames:
        _fail(
            "E301", path.name,
            f"시트 `{sheet_name}`가 없습니다. (있는 시트: {', '.join(workbook.sheetnames)})",
        )
    return workbook[sheet_name]


def _detect_language(observed: tuple, table: dict[str, tuple], location: str) -> str:
    for language, expected in table.items():
        if observed == expected:
            return language
    _fail("E302", location, f"표 머리를 알아볼 수 없어 언어를 알 수 없습니다. (읽은 값: {observed})")


def _typed(requirement: Requirement, value: Any) -> Any:
    """다중 선택은 ', '로 나눠 목록으로. 그 밖에는 읽은 그대로."""
    if requirement.type == "multi_select" and isinstance(value, str):
        return value.split(", ")
    return value


# ---------------------------------------------------------------- 양식 A: 엑셀 표

def parse_excel_a(path: str | Path, schema: Schema) -> ParsedDocument:
    path = Path(path)
    ws = _open_sheet(path, excel_a.SHEET_NAME)
    header = tuple(ws.cell(excel_a.TABLE_HEADER_ROW, c).value for c in range(1, 5))
    language = _detect_language(header, excel_a.HEADERS, path.name)
    index = _label_index(schema, language)

    items, unparsed = [], []
    for row in range(excel_a.FIRST_ITEM_ROW, ws.max_row + 1):
        label, value, unit = (ws.cell(row, c).value for c in (2, 3, 4))
        if label is None and value is None and unit is None:
            continue
        requirement = index.get(label)
        if requirement is None:
            unparsed.append(f"행 {row}: 알 수 없는 항목 {label!r}")
            continue
        items.append(ParsedItem(requirement.id, label, _typed(requirement, value), unit))

    title = ws["A1"].value
    return ParsedDocument(
        _doc_id_from_title(title, language), language, title, ws["A2"].value, tuple(items), tuple(unparsed)
    )


# ---------------------------------------------------------------- 양식 B: 워드 서술

def parse_docx_b(path: str | Path, schema: Schema) -> ParsedDocument:
    path = Path(path)
    try:
        paragraphs = [p.text for p in docx.Document(str(path)).paragraphs]
    except Exception as exc:
        _fail("E300", path.name, f"파일을 읽을 수 없습니다. ({type(exc).__name__})")

    if len(paragraphs) < LEADING_PARAGRAPHS:
        _fail("E302", path.name, "서론 문단이 없어 언어를 알 수 없습니다.")
    language = next((lang for lang, text in INTRO.items() if paragraphs[2] == text), None)
    if language is None:
        _fail("E302", path.name, f"서론 문장을 알아볼 수 없어 언어를 알 수 없습니다. (읽은 값: {paragraphs[2]!r})")

    index = _label_index(schema, language)
    items, unparsed = [], []
    for text in paragraphs[LEADING_PARAGRAPHS:]:
        if not text.strip():
            continue
        sentence = parse_item_sentence(text, list(index), language)
        if sentence is None:
            unparsed.append(text)
            continue
        requirement = index[sentence.label]
        if sentence.direction is not None:  # 숫자 문장
            items.append(ParsedItem(
                requirement.id, sentence.label, _to_number(sentence.value_text), sentence.unit_text,
                direction=sentence.direction,
            ))
        else:
            items.append(ParsedItem(
                requirement.id, sentence.label, _typed(requirement, sentence.value_text), None,
            ))

    return ParsedDocument(
        _doc_id_from_title(paragraphs[0], language), language, paragraphs[0], paragraphs[1],
        tuple(items), tuple(unparsed), has_directions=True,
    )


# ---------------------------------------------------------------- 양식 C: 엑셀 병합 매트릭스

_SPEC_NUMBER = re.compile(r"^(-?\d+(?:\.\d+)?) (.+)$")


def _parse_spec_cell(requirement: Requirement, text: Any):
    """사양 셀 하나를 (값, 단위)로. 숫자는 '값 단위'를 나눈다. 나눌 수 없으면 읽은 그대로 두어 L1이 잡게 한다."""
    if not isinstance(text, str):
        return text, None
    if requirement.type == "number":
        match = _SPEC_NUMBER.match(text)
        return (_to_number(match.group(1)), match.group(2)) if match else (text, None)
    return _typed(requirement, text), None


def parse_excel_c(path: str | Path, schema: Schema) -> ParsedDocument:
    path = Path(path)
    ws = _open_sheet(path, excel_c.SHEET_NAME)
    header = tuple(ws.cell(excel_c.HEADER_ROW, c).value for c in range(1, excel_c.COLUMNS + 1))
    language = _detect_language(header, excel_c.HEADERS, path.name)
    index = _label_index(schema, language)

    items, unparsed = [], []
    group = None
    for row in range(excel_c.FIRST_ROW, ws.max_row + 1):
        group_cell, label, spec_text, remarks = (ws.cell(row, c).value for c in range(1, excel_c.COLUMNS + 1))
        if group_cell is not None:
            group = group_cell  # 병합 영역은 왼쪽 위 셀에만 값이 있다. 아래 행으로 전파한다
        if label is None and spec_text is None and remarks is None:
            continue
        requirement = index.get(label)
        if requirement is None:
            unparsed.append(f"행 {row}: 알 수 없는 항목 {label!r}")
            continue
        value, unit = _parse_spec_cell(requirement, spec_text)
        items.append(ParsedItem(requirement.id, label, value, unit, group=group, remarks=remarks))

    title = ws["A1"].value
    return ParsedDocument(
        _doc_id_from_title(title, language), language, title, ws["A2"].value,
        tuple(items), tuple(unparsed), has_groups=True,
    )


# ---------------------------------------------------------------- L1: 문서 ↔ 표시 계획

def _same_value(kind: str, expected: Any, actual: Any) -> bool:
    if kind == "number":
        return isinstance(actual, (int, float)) and not isinstance(actual, bool) and expected == actual
    return expected == actual


def _group_key(requirement_id: str) -> str:
    return requirement_id.split(".")[0] if "." in requirement_id else "general"


def compare_with_plan(parsed: ParsedDocument, document: Document, schema: Schema) -> list[Mismatch]:
    spec = {r.id: r for r in schema.requirements}
    found: list[Mismatch] = []

    def add(requirement_id, field, expected, actual):
        found.append(Mismatch(document.doc_id, requirement_id, field, expected, actual))

    if parsed.doc_id != document.doc_id:
        add(None, "doc_id", document.doc_id, parsed.doc_id)
    if parsed.language != document.language:
        add(None, "language", document.language, parsed.language)
    for text in parsed.unparsed:
        add(None, "unparsed", None, text)

    expected = {d.id: d for d in document.display if d.present}
    by_id: dict[str, ParsedItem] = {}
    for item in parsed.items:
        if item.id in by_id:
            add(item.id, "duplicate", 1, 2)
        by_id.setdefault(item.id, item)

    for requirement_id in expected:
        if requirement_id not in by_id:
            add(requirement_id, "presence", "present", "absent")
    for requirement_id in by_id:
        if requirement_id not in expected:
            add(requirement_id, "presence", "absent", "present")

    expected_order = [d.id for d in document.display if d.present]
    parsed_order = [i.id for i in parsed.items]
    if set(expected_order) == set(parsed_order) and expected_order != parsed_order:
        add(None, "order", expected_order, parsed_order)

    for requirement_id, plan in expected.items():
        item = by_id.get(requirement_id)
        if item is None:
            continue
        requirement = spec[requirement_id]
        if not _same_value(requirement.type, plan.shown_value, item.value):
            add(requirement_id, "value", plan.shown_value, item.value)
        expected_unit = plan.shown_unit if requirement.type == "number" else None
        if item.unit != expected_unit:
            add(requirement_id, "unit", expected_unit, item.unit)
        if parsed.has_groups:
            expected_group = group_title(_group_key(requirement_id), document.language)
            if item.group != expected_group:
                add(requirement_id, "group", expected_group, item.group)
        if parsed.has_directions:
            expected_direction = (requirement.compare or "eq") if requirement.type == "number" else None
            if item.direction != expected_direction:
                add(requirement_id, "direction", expected_direction, item.direction)
        if item.remarks is not None:
            add(requirement_id, "remarks", None, item.remarks)
    return found


# ---------------------------------------------------------------- L2: 표시 ↔ 정답

def _same_truth(kind: str, expected: Any, actual: Any) -> bool:
    if kind == "number":
        return math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-12)
    return expected == actual


def check_normalization(parsed: ParsedDocument, document: Document, schema: Schema) -> NormalizationResult:
    spec = {r.id: r for r in schema.requirements}
    truth = {r.id: r for r in document.requirements}
    plan = {d.id: d for d in document.display}
    checked = skipped = 0
    found: list[Mismatch] = []

    def add(requirement_id, field, expected, actual):
        found.append(Mismatch(document.doc_id, requirement_id, field, expected, actual))

    for item in parsed.items:
        requirement, planned, answer = spec.get(item.id), plan.get(item.id), truth.get(item.id)
        if requirement is None or planned is None or answer is None or answer.value is None or not planned.present:
            continue  # 존재 여부는 L1이 본다
        unit = item.unit if requirement.type == "number" else None

        if "typo" in planned.variations:
            skipped += 1
            if requirement.type != "text":  # 오타는 알려진 표기와 같아지면 안 된다
                try:
                    normalize_shown(requirement, item.value, unit)
                except (UnknownNotation, TypeError):
                    continue
                add(item.id, "typo_resolved", "해석 불가", "해석됨")
            continue

        try:
            actual = normalize_shown(requirement, item.value, unit)
        except (UnknownNotation, TypeError) as exc:
            add(item.id, "normalize", answer.value, str(exc))
            continue
        checked += 1
        if not _same_truth(requirement.type, answer.value, actual):
            add(item.id, "truth", answer.value, actual)

    return NormalizationResult(checked, skipped, tuple(found))
