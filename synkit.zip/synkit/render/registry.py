"""(양식 종류, 레이아웃) → 렌더러·파서·확장자. (devplan 4.7)

스키마가 허용하는 조합은 모두 여기서 지원해야 한다. (schema/semantic_checks.py의 `_COMPATIBLE_LAYOUTS`와
같은 목록이며 tests/test_render_registry.py가 일치를 확인한다)
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from synkit.generate.models import Document
from synkit.render.docx_b import write_docx_b
from synkit.render.excel_a import write_excel_a
from synkit.render.excel_c import write_excel_c
from synkit.render.model import DocumentView
from synkit.render.roundtrip import (
    ParsedDocument,
    RoundtripResult,
    check_normalization,
    compare_with_plan,
    parse_docx_b,
    parse_excel_a,
    parse_excel_c,
)
from synkit.schema.models import Schema, Template


class UnsupportedTemplate(ValueError):
    """렌더러가 없는 (양식 종류, 레이아웃) 조합."""


@dataclass(frozen=True)
class TemplateSupport:
    extension: str
    write: Callable[[DocumentView, Path], Path]
    parse: Callable[[Path, Schema], ParsedDocument]


_SUPPORT = {
    ("excel", "table_rows"): TemplateSupport(".xlsx", write_excel_a, parse_excel_a),
    ("docx", "narrative"): TemplateSupport(".docx", write_docx_b, parse_docx_b),
    ("excel", "matrix_merged_cells"): TemplateSupport(".xlsx", write_excel_c, parse_excel_c),
}


def support_for(template: Template) -> TemplateSupport:
    try:
        return _SUPPORT[(template.kind, template.layout)]
    except KeyError:
        supported = ", ".join(f"{k}/{l}" for k, l in _SUPPORT)
        raise UnsupportedTemplate(
            f"지원하지 않는 양식 조합입니다: kind={template.kind}, layout={template.layout} (지원: {supported})"
        ) from None


def document_filename(doc_id: str, template: Template) -> str:
    return f"{doc_id}{support_for(template).extension}"


def render_document(view: DocumentView, template: Template, directory: str | Path) -> Path:
    path = Path(directory) / document_filename(view.doc_id, template)
    return support_for(template).write(view, path)


def parse_document(path: str | Path, schema: Schema, template: Template) -> ParsedDocument:
    return support_for(template).parse(Path(path), schema)


def roundtrip_document(
    path: str | Path, schema: Schema, template: Template, document: Document
) -> RoundtripResult:
    """문서 파일을 읽어 L1(표시 계획)과 L2(정답)에 대조한다."""
    parsed = parse_document(path, schema, template)
    return RoundtripResult(
        parsed,
        tuple(compare_with_plan(parsed, document, schema)),
        check_normalization(parsed, document, schema),
    )
