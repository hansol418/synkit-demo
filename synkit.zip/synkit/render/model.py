"""렌더 공통 모델: 문서에 무엇이 어떻게 찍히는가. (devplan 4.3, 양식 A·B·C가 공유)

입력은 정답(ground_truth)이 아니라 **표시 계획(document_plan)**이다. 그래서 별칭, 환산 단위, 오타가
들어간 모습 그대로 문서에 찍히고, 누락된 항목은 문서에 없다. 파일 형식(Excel, Word)은 여기서 다루지 않는다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Any

from synkit.constants import (
    SYNTHETIC_DOCUMENT_MARK,
    SYNTHETIC_DOCUMENT_MARK_EN,
    SYNTHETIC_TOKEN,
)
from synkit.generate.models import Document
from synkit.run_io import RunData
from synkit.schema.labels import LANGUAGES, label_for
from synkit.schema.models import Schema

# 파일 속성의 시각은 실행 시각이 아니라 고정값을 쓴다. (문서 재현성, 결정 28)
FIXED_TIMESTAMP = datetime(2000, 1, 1, 0, 0, 0)

TITLES = {"ko": "견적 요청 사양서", "en": "RFQ Specification"}
_MARK_MESSAGES = {"ko": SYNTHETIC_DOCUMENT_MARK, "en": SYNTHETIC_DOCUMENT_MARK_EN}
CREATOR = "synkit (synthetic data)"


# 그룹(id의 첫 단어)의 표시 이름. 스키마에 그룹 이름 필드는 없으므로 흔한 단어만 내장하고,
# 그 밖의 단어는 읽기 좋게 바꿔 쓴다. (양식 C의 병합 그룹 셀에 쓴다. 결정 37)
GROUP_TITLES = {
    "electrical": {"ko": "전기", "en": "Electrical"},
    "performance": {"ko": "성능", "en": "Performance"},
    "durability": {"ko": "내구", "en": "Durability"},
    "mechanical": {"ko": "기구", "en": "Mechanical"},
    "certification": {"ko": "인증", "en": "Certification"},
    "general": {"ko": "일반", "en": "General"},
}


def _check_language(language: str) -> None:
    if language not in LANGUAGES:
        raise ValueError(f"지원하지 않는 언어입니다: {language!r} (지원: {', '.join(LANGUAGES)})")


def group_title(group: str, language: str) -> str:
    """그룹 키(electrical)를 문서 언어의 이름으로. 내장 이름이 없으면 단어를 읽기 좋게 바꿔 쓴다."""
    _check_language(language)
    known = GROUP_TITLES.get(group)
    if known:
        return known[language]
    words = group.replace("_", " ").strip()
    return words[:1].upper() + words[1:]


def synthetic_mark(language: str) -> str:
    """문서 머리와 파일 속성에 넣는 합성 표시. 언어와 무관한 토큰으로 시작한다."""
    _check_language(language)
    return f"{SYNTHETIC_TOKEN} {_MARK_MESSAGES[language]}"


def format_number(value: int | float) -> str:
    """숫자를 문서에 찍을 문자열로. 지수 표기와 불필요한 `.0`을 쓰지 않고, 다시 읽으면 같은 값이다.

    정수값 소수는 정수로(12.0 → 12), 그 밖에는 가장 짧은 십진 표기(11.8, 0.0000005)로 쓴다.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"숫자가 아닙니다: {value!r}")
    if isinstance(value, int):
        return str(value)
    if value != value or value in (float("inf"), float("-inf")):
        raise ValueError(f"유한한 숫자가 아닙니다: {value!r}")
    if value.is_integer():
        return str(int(value))
    return format(Decimal(repr(value)), "f")


@dataclass(frozen=True)
class ViewItem:
    id: str
    group: str  # id의 첫 단어. 점이 없으면 "general" (양식 C의 병합 그룹에 쓴다)
    kind: str  # 요구사항 유형: number, category, multi_select, text
    label: str  # 문서 언어에 맞는 항목 이름
    shown_value: Any  # 표시 계획의 값(환산·오타 포함, 타입 유지)
    value_text: str  # 문서에 찍을 값 문자열 (단위 제외)
    unit_text: str | None  # 문서에 찍힌 단위 문자열(별칭·오타 포함)
    compare: str | None  # 숫자만: eq / min / max
    converted_from: str | None
    variations: tuple[str, ...]

    @property
    def value_with_unit(self) -> str:
        return f"{self.value_text} {self.unit_text}" if self.unit_text else self.value_text


@dataclass(frozen=True)
class DocumentView:
    doc_id: str
    template: str
    language: str
    title: str
    synthetic_mark: str
    properties: dict[str, str]  # 파일 속성(제작자, 제목, 주제, 키워드)에 넣을 값. 합성 문서임을 담는다
    items: tuple[ViewItem, ...]


def _value_text(kind: str, shown_value: Any) -> str:
    if kind == "number":
        return format_number(shown_value)
    if kind == "multi_select":
        return ", ".join(shown_value)
    return str(shown_value)


def build_view(schema: Schema, document: Document) -> DocumentView:
    _check_language(document.language)
    spec = {r.id: r for r in schema.requirements}

    items = []
    for display in document.display:
        if not display.present:  # 누락된 항목은 문서에 없다
            continue
        requirement = spec[display.id]
        items.append(
            ViewItem(
                id=display.id,
                group=display.id.split(".")[0] if "." in display.id else "general",
                kind=requirement.type,
                label=label_for(requirement, document.language),
                shown_value=display.shown_value,
                value_text=_value_text(requirement.type, display.shown_value),
                unit_text=display.shown_unit,
                compare=(requirement.compare or "eq") if requirement.type == "number" else None,
                converted_from=display.converted_from,
                variations=display.variations,
            )
        )

    title = f"{TITLES[document.language]} {document.doc_id}"
    mark = synthetic_mark(document.language)
    return DocumentView(
        doc_id=document.doc_id,
        template=document.template,
        language=document.language,
        title=title,
        synthetic_mark=mark,
        properties={"creator": CREATOR, "title": title, "subject": mark, "keywords": "synthetic"},
        items=tuple(items),
    )


def build_views(run: RunData) -> tuple[DocumentView, ...]:
    return tuple(build_view(run.schema, document) for document in run.dataset.documents)
