"""양식 C (excel / matrix_merged_cells): 보류 양식. 가장 까다로운 구조. (devplan 4.6)

보류 양식이므로 개발 중 튜닝 대상이 아니다. 일부러 A·B와 구조를 다르게 했다. (D3, 순환 평가 방지)

레이아웃 (왕복 파서가 같은 상수를 쓴다)
  시트 `Spec` · 1행 제목(A:D 병합) · 2행 합성 표시(A:D 병합) · 3행 비움 · 4행 표 머리 · 5행부터 항목
  열: 구분(그룹) | 항목 | 사양(값과 단위가 한 셀, 예: `12 volts`) | 비고(항상 비어 있음)
  구분 열은 같은 그룹이 이어지는 구간을 **세로로 병합**한다. 병합 영역에서는 값이 왼쪽 위 셀에만 있다.
  한 줄짜리 구간은 병합하지 않는다. 누락된 항목은 행이 없고, 항목이 모두 없는 그룹은 나타나지 않는다.
"""

from __future__ import annotations

from itertools import groupby
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from synkit.render.excel_common import apply_properties, max_display_width, set_text
from synkit.render.model import DocumentView, group_title
from synkit.render.ooxml import normalize_package

SHEET_NAME = "Spec"
HEADER_ROW = 4
FIRST_ROW = 5
COLUMNS = 4
HEADERS = {
    "ko": ("구분", "항목", "사양", "비고"),
    "en": ("Group", "Item", "Specification", "Remarks"),
}

_HEADER_FILL = PatternFill("solid", fgColor="D9E1F2")
_THIN = Side(style="thin", color="999999")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)


def build_workbook(view: DocumentView) -> Workbook:
    wb = Workbook()
    ws = wb.active
    ws.title = SHEET_NAME

    set_text(ws["A1"], view.title)
    ws["A1"].font = Font(bold=True, size=14)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=COLUMNS)
    set_text(ws["A2"], view.synthetic_mark)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=COLUMNS)

    headers = HEADERS[view.language]
    for column, header in enumerate(headers, start=1):
        cell = ws.cell(HEADER_ROW, column)
        set_text(cell, header)
        cell.font = Font(bold=True)
        cell.fill = _HEADER_FILL
        cell.border = _BORDER

    row = FIRST_ROW
    for group, run in groupby(view.items, key=lambda i: i.group):
        run = list(run)
        start = row
        for item in run:
            set_text(ws.cell(row, 2), item.label)
            set_text(ws.cell(row, 3), item.value_with_unit)  # 값과 단위를 한 셀에
            ws.cell(row, 3).alignment = Alignment(wrap_text=True, vertical="top")
            for column in range(1, COLUMNS + 1):
                ws.cell(row, column).border = _BORDER
            row += 1
        set_text(ws.cell(start, 1), group_title(group, view.language))
        ws.cell(start, 1).alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        if len(run) > 1:  # 한 줄짜리 구간은 병합하지 않는다
            ws.merge_cells(start_row=start, start_column=1, end_row=row - 1, end_column=1)

    groups = [headers[0]] + [group_title(i.group, view.language) for i in view.items]
    labels = [headers[1]] + [i.label for i in view.items]
    specs = [headers[2]] + [i.value_with_unit for i in view.items]
    ws.column_dimensions["A"].width = max(10, max_display_width(groups) + 2)
    ws.column_dimensions["B"].width = max(12, max_display_width(labels) + 2)
    ws.column_dimensions["C"].width = min(60, max(18, max_display_width(specs) + 2))
    ws.column_dimensions["D"].width = max(10, max_display_width([headers[3]]) + 2)

    apply_properties(wb, view)
    return wb


def write_excel_c(view: DocumentView, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    build_workbook(view).save(path)
    return normalize_package(path)
