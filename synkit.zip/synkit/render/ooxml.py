"""저장한 xlsx·docx를 고정 시각으로 다시 포장해 바이트 동일을 얻는다. (결정 28, 41)

실측한 바이트 차이의 원인은 두 가지였다.
  ① zip 항목의 저장 시각 (2초 단위 DOS 시각)
  ② openpyxl이 저장할 때 core.xml의 modified를 현재 시각으로 덮어쓰는 것 (openpyxl/excel.py)
라이브러리 내부를 건드리지 않고, 저장이 끝난 파일을 읽어 core.xml의 created·modified를 고정하고
모든 항목을 고정 시각·고정 속성으로 다시 쓴다. 항목 이름과 순서, 내용(core.xml 시각 제외)은 그대로다.
"""

from __future__ import annotations

import os
import re
import zipfile
from pathlib import Path

ZIP_TIMESTAMP = (2000, 1, 1, 0, 0, 0)  # zip 형식은 1980년 이후만 표현한다
CORE_TIMESTAMP = "2000-01-01T00:00:00Z"

_CORE_PART = "docProps/core.xml"
_CORE_TIME = re.compile(r"(<dcterms:(?:created|modified)\b[^>]*>)[^<]*(</dcterms:(?:created|modified)>)")
_FILE_MODE = 0o644 << 16
_CREATE_SYSTEM_UNIX = 3  # 운영체제와 무관하게 같은 값을 쓴다. (기본값은 실행 환경에 따라 다르다)


def _fix_core(data: bytes) -> bytes:
    text = data.decode("utf-8")
    return _CORE_TIME.sub(rf"\g<1>{CORE_TIMESTAMP}\g<2>", text).encode("utf-8")


def normalize_package(path: str | Path) -> Path:
    """xlsx/docx 파일을 제자리에서 고정 시각으로 다시 쓴다. 실패하면 원본을 그대로 두고 임시 파일을 지운다."""
    path = Path(path)
    temp = path.with_name(path.name + ".tmp")
    with zipfile.ZipFile(path) as source:  # zip이 아니면 BadZipFile (원본은 그대로)
        try:
            with zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED) as target:
                for info in source.infolist():
                    data = source.read(info.filename)
                    if info.filename == _CORE_PART:
                        data = _fix_core(data)
                    fixed = zipfile.ZipInfo(info.filename, ZIP_TIMESTAMP)
                    fixed.compress_type = zipfile.ZIP_DEFLATED
                    fixed.create_system = _CREATE_SYSTEM_UNIX
                    fixed.external_attr = _FILE_MODE
                    target.writestr(fixed, data)
        except BaseException:
            temp.unlink(missing_ok=True)
            raise
    os.replace(temp, path)
    return path
