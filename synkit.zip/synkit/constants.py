"""모든 산출물이 참조하는 고정 문구.

한계 고지는 여기 한 곳에서만 정의한다. CLI, 리포트, 문서 렌더링이 모두 이 상수를 가져다 쓰므로
문구가 여러 곳에서 어긋나지 않는다. (초안: M7 리포트 작업 때 최종 문구를 확정한다)
"""

# 실행 폴더(runs/<run_id>/)의 구조 버전. 파일 구성이나 형식이 호환되지 않게 바뀔 때만 올린다.
# run_meta.json에 기록되고, run_io가 읽기 전에 확인한다. (docs/decisions.md 31번)
CONTRACT_VERSION = 1

# 산출물 어디서나 쓰는 짧은 표기 (배너, 문서 머리, 점수 옆)
SYNTHETIC_TAG = "합성 데이터 기준 (실성능 아님)"

# 리포트 첫 섹션과 CLI 시작 고지에 쓰는 본문
LIMITATION_NOTICE = (
    "이 결과는 합성 데이터를 기준으로 한다. "
    "방법의 타당성을 확인하는 용도이며 실제 문서에서의 성능을 보증하지 않는다. "
    "실제 문서의 오류, 스캔 품질, 양식 다양성은 재현하지 못한다."
)

# 합성 문서(Excel, DOCX) 머리에 넣는 표시. 언어와 무관한 토큰(SYNTHETIC_TOKEN)으로 시작해
# 점검(단계 5)이 문서 언어와 상관없이 합성 표시를 찾을 수 있게 한다.
SYNTHETIC_TOKEN = "[SYNTHETIC]"
SYNTHETIC_DOCUMENT_MARK = "합성 문서: 실제 고객 문서가 아님"
SYNTHETIC_DOCUMENT_MARK_EN = "Synthetic document: not a real customer document"

# `grade`가 채점 결과를 이력으로 보관하는 폴더와, 그 파일 이름에 쓰는 제출물 해시의 앞자리 수. (ADR 0008)
GRADE_HISTORY_DIR = "grades"
GRADE_HISTORY_HASH_LENGTH = 12
